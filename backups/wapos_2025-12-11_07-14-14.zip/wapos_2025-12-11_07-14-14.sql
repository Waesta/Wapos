-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: wapos
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_reconciliations`
--

DROP TABLE IF EXISTS `account_reconciliations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_reconciliations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(10) unsigned NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `statement_balance` decimal(15,2) NOT NULL,
  `ledger_balance` decimal(15,2) NOT NULL,
  `variance` decimal(15,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('draft','submitted','approved') DEFAULT 'draft',
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_account_period` (`account_id`,`period_start`,`period_end`),
  CONSTRAINT `account_reconciliations_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `account_reconciliations_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_reconciliations`
--

LOCK TABLES `account_reconciliations` WRITE;
/*!40000 ALTER TABLE `account_reconciliations` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_reconciliations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting_periods`
--

DROP TABLE IF EXISTS `accounting_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_periods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `period_name` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('open','closed','locked') NOT NULL DEFAULT 'open',
  `locked_by` int(10) unsigned DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_period_dates` (`start_date`,`end_date`),
  KEY `locked_by` (`locked_by`),
  CONSTRAINT `accounting_periods_ibfk_1` FOREIGN KEY (`locked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_periods`
--

LOCK TABLES `accounting_periods` WRITE;
/*!40000 ALTER TABLE `accounting_periods` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `type` enum('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE','CONTRA_REVENUE','COST_OF_SALES','OTHER_INCOME','OTHER_EXPENSE') NOT NULL,
  `classification` enum('ASSET','LIABILITY','EQUITY','REVENUE','OTHER_INCOME','OPERATING_EXPENSE','NON_OPERATING_EXPENSE','OTHER_EXPENSE','COST_OF_SALES') NOT NULL DEFAULT 'ASSET',
  `statement_section` enum('BALANCE_SHEET','PROFIT_AND_LOSS','CASH_FLOW','EQUITY') NOT NULL DEFAULT 'PROFIT_AND_LOSS',
  `reporting_order` int(10) unsigned NOT NULL DEFAULT 0,
  `parent_code` varchar(20) DEFAULT NULL,
  `ifrs_reference` varchar(50) DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `accounts_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'1000','Cash and Cash Equivalents','ASSET','','BALANCE_SHEET',100,NULL,'IFRS-SME 7.2',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(2,'1010','Petty Cash','ASSET','','BALANCE_SHEET',110,'1000','IFRS-SME 7.2',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(3,'1100','Bank Accounts','ASSET','','BALANCE_SHEET',120,NULL,'IFRS-SME 7.2',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(4,'1200','Accounts Receivable','ASSET','','BALANCE_SHEET',200,NULL,'IFRS-SME 11.13',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(5,'1300','Inventory','ASSET','','BALANCE_SHEET',210,NULL,'IFRS-SME 13.4',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(6,'1400','Prepaid Expenses','ASSET','','BALANCE_SHEET',220,NULL,'IFRS-SME 11.14',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(7,'1500','Property, Plant and Equipment','ASSET','','BALANCE_SHEET',300,NULL,'IFRS-SME 17.10',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(8,'1600','Accumulated Depreciation','ASSET','','BALANCE_SHEET',305,'1500','IFRS-SME 17.23',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(9,'2000','Accounts Payable','LIABILITY','','BALANCE_SHEET',400,NULL,'IFRS-SME 11.17',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(10,'2100','Sales Tax Payable','LIABILITY','','BALANCE_SHEET',410,NULL,'IFRS-SME 29.12',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(11,'2200','Accrued Expenses','LIABILITY','','BALANCE_SHEET',420,NULL,'IFRS-SME 11.17',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(12,'2300','Short-term Loans','LIABILITY','','BALANCE_SHEET',430,NULL,'IFRS-SME 11.13',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(13,'2400','Long-term Loans','LIABILITY','','BALANCE_SHEET',500,NULL,'IFRS-SME 11.14',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(14,'3000','Owner\'s Capital','EQUITY','EQUITY','EQUITY',600,NULL,'IFRS-SME 6.3',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(15,'3100','Retained Earnings','EQUITY','EQUITY','EQUITY',610,'3000','IFRS-SME 6.5',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(16,'3200','Owner Drawings','EQUITY','','EQUITY',620,'3000','IFRS-SME 6.7',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(17,'4000','Sales Revenue','REVENUE','REVENUE','PROFIT_AND_LOSS',700,NULL,'IFRS-SME 23.30',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(18,'4100','Service Revenue','REVENUE','REVENUE','PROFIT_AND_LOSS',710,'4000','IFRS-SME 23.30',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(19,'4200','Other Operating Income','OTHER_INCOME','OTHER_INCOME','PROFIT_AND_LOSS',720,NULL,'IFRS-SME 23.30',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(20,'4500','Sales Returns and Allowances','CONTRA_REVENUE','','PROFIT_AND_LOSS',730,'4000','IFRS-SME 23.31',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(21,'4510','Sales Discounts','CONTRA_REVENUE','','PROFIT_AND_LOSS',735,'4000','IFRS-SME 23.31',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(22,'5000','Cost of Goods Sold','EXPENSE','COST_OF_SALES','PROFIT_AND_LOSS',800,NULL,'IFRS-SME 13.19',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(23,'5100','Direct Labour','EXPENSE','COST_OF_SALES','PROFIT_AND_LOSS',810,'5000','IFRS-SME 13.19',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(24,'5200','Freight Inwards','EXPENSE','COST_OF_SALES','PROFIT_AND_LOSS',820,'5000','IFRS-SME 13.19',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(25,'6000','Operating Expenses','EXPENSE','OPERATING_EXPENSE','PROFIT_AND_LOSS',900,NULL,'IFRS-SME 2.52',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(26,'6100','Salaries and Wages','EXPENSE','OPERATING_EXPENSE','PROFIT_AND_LOSS',910,'6000','IFRS-SME 2.52',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(27,'6200','Rent Expense','EXPENSE','OPERATING_EXPENSE','PROFIT_AND_LOSS',920,'6000','IFRS-SME 2.52',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(28,'6300','Utilities Expense','EXPENSE','OPERATING_EXPENSE','PROFIT_AND_LOSS',930,'6000','IFRS-SME 2.52',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(29,'6400','Marketing Expense','EXPENSE','OPERATING_EXPENSE','PROFIT_AND_LOSS',940,'6000','IFRS-SME 2.52',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(30,'6500','Depreciation Expense','EXPENSE','OPERATING_EXPENSE','PROFIT_AND_LOSS',950,'6000','IFRS-SME 17.23',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(31,'6600','Finance Costs','EXPENSE','NON_OPERATING_EXPENSE','PROFIT_AND_LOSS',960,NULL,'IFRS-SME 25.3',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29'),(32,'6700','Other Expenses','EXPENSE','OTHER_EXPENSE','PROFIT_AND_LOSS',970,NULL,'IFRS-SME 2.52',NULL,1,'2025-12-01 07:40:29','2025-12-01 07:40:29');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `table_name` varchar(100) DEFAULT NULL,
  `record_id` int(10) unsigned DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_table_record` (`table_name`,`record_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created` (`created_at`),
  KEY `idx_audit_table` (`table_name`,`record_id`),
  KEY `idx_audit_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `record_id` int(10) unsigned DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_date` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backup_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `backup_file` varchar(255) NOT NULL,
  `backup_size` bigint(20) DEFAULT NULL,
  `backup_type` enum('auto','manual') DEFAULT 'manual',
  `status` enum('success','failed','running') NOT NULL DEFAULT 'running',
  `message` text DEFAULT NULL,
  `storage_path` varchar(255) NOT NULL DEFAULT '',
  `initiated_by` int(10) unsigned DEFAULT NULL,
  `retention_days` int(11) DEFAULT 30,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `backup_logs_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_logs`
--

LOCK TABLES `backup_logs` WRITE;
/*!40000 ALTER TABLE `backup_logs` DISABLE KEYS */;
INSERT INTO `backup_logs` VALUES (1,'wapos_2025-12-02_08-21-41.zip',20428,'manual','success','Backup completed successfully','C:\\xampp\\htdocs\\wapos/backups',1,30,NULL,'2025-12-02 05:21:41'),(2,'wapos_2025-12-03_18-55-43.zip',27388,'manual','success','Backup completed successfully','C:\\xampp\\htdocs\\wapos/backups',1,30,NULL,'2025-12-03 15:55:43'),(3,'wapos_2025-12-09_13-59-35.zip',36631,'auto','success','Backup completed successfully','C:\\xampp\\htdocs\\wapos/backups',NULL,30,NULL,'2025-12-09 10:59:35'),(4,'wapos_2025-12-11_07-14-14.zip',0,'auto','running','','C:\\xampp\\htdocs\\wapos/backups',NULL,30,NULL,'2025-12-11 04:14:14');
/*!40000 ALTER TABLE `backup_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_open_stock`
--

DROP TABLE IF EXISTS `bar_open_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_open_stock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL COMMENT 'Bar location if multiple bars',
  `bottle_size_ml` int(11) NOT NULL,
  `remaining_ml` decimal(10,2) NOT NULL,
  `opened_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `opened_by` int(10) unsigned DEFAULT NULL,
  `status` enum('open','empty','disposed') DEFAULT 'open',
  `notes` varchar(255) DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_status` (`status`),
  KEY `idx_location` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_open_stock`
--

LOCK TABLES `bar_open_stock` WRITE;
/*!40000 ALTER TABLE `bar_open_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_open_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_order_tickets`
--

DROP TABLE IF EXISTS `bar_order_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_order_tickets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bot_number` varchar(30) NOT NULL COMMENT 'BOT-YYMMDD-XXXX format',
  `source_type` enum('tab','order','room_service','pos') NOT NULL,
  `tab_id` int(10) unsigned DEFAULT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `sale_id` int(10) unsigned DEFAULT NULL,
  `bar_station` varchar(50) NOT NULL DEFAULT 'Main Bar',
  `priority` enum('normal','rush','vip') DEFAULT 'normal',
  `items` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Array of items with portions/modifiers' CHECK (json_valid(`items`)),
  `item_count` int(11) NOT NULL DEFAULT 0,
  `status` enum('pending','acknowledged','preparing','ready','picked_up','cancelled') DEFAULT 'pending',
  `acknowledged_by` int(10) unsigned DEFAULT NULL,
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `prepared_by` int(10) unsigned DEFAULT NULL,
  `prepared_at` timestamp NULL DEFAULT NULL,
  `picked_up_at` timestamp NULL DEFAULT NULL,
  `estimated_time_minutes` int(11) DEFAULT 5,
  `actual_time_minutes` int(11) DEFAULT NULL,
  `print_count` int(11) DEFAULT 0,
  `last_printed_at` timestamp NULL DEFAULT NULL,
  `auto_printed` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_bot_number` (`bot_number`),
  KEY `idx_status` (`status`),
  KEY `idx_station` (`bar_station`),
  KEY `idx_tab` (`tab_id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_order_tickets`
--

LOCK TABLES `bar_order_tickets` WRITE;
/*!40000 ALTER TABLE `bar_order_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_order_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_pour_log`
--

DROP TABLE IF EXISTS `bar_pour_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_pour_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `open_stock_id` int(10) unsigned DEFAULT NULL,
  `sale_id` int(10) unsigned DEFAULT NULL,
  `sale_item_id` int(10) unsigned DEFAULT NULL,
  `pour_type` enum('sale','wastage','spillage','comp','staff','adjustment') DEFAULT 'sale',
  `quantity_ml` decimal(10,2) NOT NULL,
  `quantity_portions` decimal(10,4) DEFAULT 1.0000,
  `portion_name` varchar(100) DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_sale` (`sale_id`),
  KEY `idx_type` (`pour_type`),
  KEY `idx_date` (`created_at`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_pour_log`
--

LOCK TABLES `bar_pour_log` WRITE;
/*!40000 ALTER TABLE `bar_pour_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_pour_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_recipe_ingredients`
--

DROP TABLE IF EXISTS `bar_recipe_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_recipe_ingredients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recipe_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `quantity_ml` decimal(10,2) DEFAULT NULL COMMENT 'Quantity in ml for liquids',
  `quantity_units` decimal(10,4) DEFAULT NULL COMMENT 'Quantity in units for non-liquids',
  `is_optional` tinyint(1) DEFAULT 0,
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_recipe` (`recipe_id`),
  KEY `idx_product` (`product_id`),
  CONSTRAINT `bar_recipe_ingredients_ibfk_1` FOREIGN KEY (`recipe_id`) REFERENCES `bar_recipes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_recipe_ingredients`
--

LOCK TABLES `bar_recipe_ingredients` WRITE;
/*!40000 ALTER TABLE `bar_recipe_ingredients` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_recipe_ingredients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_recipes`
--

DROP TABLE IF EXISTS `bar_recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_recipes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT 'Cocktail',
  `selling_price` decimal(15,2) NOT NULL,
  `preparation_notes` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_category` (`category`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_recipes`
--

LOCK TABLES `bar_recipes` WRITE;
/*!40000 ALTER TABLE `bar_recipes` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_recipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_stations`
--

DROP TABLE IF EXISTS `bar_stations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_stations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `color` varchar(7) DEFAULT '#17a2b8',
  `icon` varchar(50) DEFAULT 'bi-cup-straw',
  `serves_cocktails` tinyint(1) DEFAULT 1,
  `serves_wine` tinyint(1) DEFAULT 1,
  `serves_beer` tinyint(1) DEFAULT 1,
  `serves_spirits` tinyint(1) DEFAULT 1,
  `serves_soft_drinks` tinyint(1) DEFAULT 1,
  `printer_name` varchar(100) DEFAULT NULL,
  `printer_ip` varchar(45) DEFAULT NULL,
  `auto_print_bot` tinyint(1) DEFAULT 1,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_location` (`location_id`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_stations`
--

LOCK TABLES `bar_stations` WRITE;
/*!40000 ALTER TABLE `bar_stations` DISABLE KEYS */;
INSERT INTO `bar_stations` VALUES (1,'Main Bar','MAIN',NULL,1,'#17a2b8','bi-cup-straw',1,1,1,1,1,NULL,NULL,1,1,'2025-12-09 08:53:45'),(2,'Pool Bar','POOL',NULL,2,'#20c997','bi-water',1,1,1,1,1,NULL,NULL,1,1,'2025-12-09 08:53:45'),(3,'Lounge Bar','LOUNGE',NULL,3,'#6f42c1','bi-moon-stars',1,1,1,1,1,NULL,NULL,1,1,'2025-12-09 08:53:45'),(4,'Restaurant Bar','REST',NULL,4,'#fd7e14','bi-shop',1,1,1,1,1,NULL,NULL,1,1,'2025-12-09 08:53:45'),(5,'Room Service Bar','ROOM',NULL,5,'#e83e8c','bi-door-open',1,1,1,1,1,NULL,NULL,1,1,'2025-12-09 08:53:45');
/*!40000 ALTER TABLE `bar_stations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_tab_items`
--

DROP TABLE IF EXISTS `bar_tab_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_tab_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tab_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `portion_id` int(10) unsigned DEFAULT NULL COMMENT 'Specific portion if applicable',
  `recipe_id` int(10) unsigned DEFAULT NULL COMMENT 'If cocktail/recipe',
  `item_name` varchar(200) NOT NULL,
  `portion_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `modifiers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Ice, garnish, mixer preferences' CHECK (json_valid(`modifiers`)),
  `special_instructions` text DEFAULT NULL,
  `status` enum('pending','preparing','ready','served','voided') DEFAULT 'pending',
  `served_by` int(10) unsigned DEFAULT NULL,
  `served_at` timestamp NULL DEFAULT NULL,
  `voided_by` int(10) unsigned DEFAULT NULL,
  `voided_at` timestamp NULL DEFAULT NULL,
  `void_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tab` (`tab_id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `bar_tab_items_ibfk_1` FOREIGN KEY (`tab_id`) REFERENCES `bar_tabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_tab_items`
--

LOCK TABLES `bar_tab_items` WRITE;
/*!40000 ALTER TABLE `bar_tab_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_tab_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_tab_payments`
--

DROP TABLE IF EXISTS `bar_tab_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_tab_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tab_id` int(10) unsigned NOT NULL,
  `payment_method` enum('cash','card','mpesa','airtel','mtn','room_charge','member_charge','comp','split') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tip_amount` decimal(15,2) DEFAULT 0.00,
  `reference_number` varchar(100) DEFAULT NULL,
  `card_last_four` varchar(4) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `room_number` varchar(20) DEFAULT NULL,
  `split_guest_name` varchar(100) DEFAULT NULL,
  `split_portion_percent` decimal(5,2) DEFAULT NULL,
  `processed_by` int(10) unsigned NOT NULL,
  `processed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tab` (`tab_id`),
  KEY `idx_method` (`payment_method`),
  CONSTRAINT `bar_tab_payments_ibfk_1` FOREIGN KEY (`tab_id`) REFERENCES `bar_tabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_tab_payments`
--

LOCK TABLES `bar_tab_payments` WRITE;
/*!40000 ALTER TABLE `bar_tab_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_tab_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_tab_transfers`
--

DROP TABLE IF EXISTS `bar_tab_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_tab_transfers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from_tab_id` int(10) unsigned NOT NULL,
  `to_tab_id` int(10) unsigned DEFAULT NULL COMMENT 'NULL if transferred to order',
  `to_order_id` int(10) unsigned DEFAULT NULL COMMENT 'Restaurant order if applicable',
  `to_room_folio_id` int(10) unsigned DEFAULT NULL COMMENT 'Room folio if applicable',
  `transfer_type` enum('tab_to_tab','tab_to_order','tab_to_room','items_only') NOT NULL,
  `items_transferred` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Specific items if partial transfer' CHECK (json_valid(`items_transferred`)),
  `amount_transferred` decimal(15,2) NOT NULL,
  `transferred_by` int(10) unsigned NOT NULL,
  `transferred_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_from` (`from_tab_id`),
  KEY `idx_to_tab` (`to_tab_id`),
  KEY `idx_to_order` (`to_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_tab_transfers`
--

LOCK TABLES `bar_tab_transfers` WRITE;
/*!40000 ALTER TABLE `bar_tab_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_tab_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_tabs`
--

DROP TABLE IF EXISTS `bar_tabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_tabs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tab_number` varchar(20) NOT NULL,
  `tab_name` varchar(100) NOT NULL COMMENT 'Guest name or card last 4 digits',
  `tab_type` enum('name','card','room','member') DEFAULT 'name',
  `customer_id` int(10) unsigned DEFAULT NULL,
  `room_booking_id` int(10) unsigned DEFAULT NULL COMMENT 'Link to room folio',
  `member_id` varchar(50) DEFAULT NULL COMMENT 'Loyalty/membership ID',
  `preauth_amount` decimal(15,2) DEFAULT NULL COMMENT 'Card pre-auth hold amount',
  `preauth_reference` varchar(100) DEFAULT NULL,
  `preauth_expires_at` timestamp NULL DEFAULT NULL,
  `card_last_four` varchar(4) DEFAULT NULL,
  `card_type` varchar(20) DEFAULT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `bar_station` varchar(50) DEFAULT NULL COMMENT 'Main Bar, Pool Bar, etc.',
  `table_id` int(10) unsigned DEFAULT NULL,
  `server_id` int(10) unsigned NOT NULL COMMENT 'Bartender/waiter who opened',
  `subtotal` decimal(15,2) DEFAULT 0.00,
  `tax_amount` decimal(15,2) DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `tip_amount` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `status` enum('open','pending_payment','paid','transferred','voided','charged_to_room') DEFAULT 'open',
  `guest_count` int(11) DEFAULT 1,
  `notes` text DEFAULT NULL,
  `opened_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `closed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tab_number` (`tab_number`),
  KEY `idx_status` (`status`),
  KEY `idx_server` (`server_id`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_room` (`room_booking_id`),
  KEY `idx_location` (`location_id`),
  KEY `idx_opened` (`opened_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_tabs`
--

LOCK TABLES `bar_tabs` WRITE;
/*!40000 ALTER TABLE `bar_tabs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_tabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bar_variance_reports`
--

DROP TABLE IF EXISTS `bar_variance_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bar_variance_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `report_date` date NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `opening_stock_ml` decimal(15,2) NOT NULL,
  `purchases_ml` decimal(15,2) DEFAULT 0.00,
  `expected_usage_ml` decimal(15,2) NOT NULL COMMENT 'Based on sales',
  `actual_usage_ml` decimal(15,2) NOT NULL COMMENT 'Based on stock count',
  `variance_ml` decimal(15,2) NOT NULL,
  `variance_percent` decimal(5,2) NOT NULL,
  `variance_value` decimal(15,2) NOT NULL COMMENT 'Cost of variance',
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_date_product` (`report_date`,`product_id`),
  KEY `idx_date` (`report_date`),
  KEY `idx_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bar_variance_reports`
--

LOCK TABLES `bar_variance_reports` WRITE;
/*!40000 ALTER TABLE `bar_variance_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `bar_variance_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `booking_number` varchar(50) NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `room_id` int(10) unsigned NOT NULL,
  `check_in` date NOT NULL,
  `check_out` date NOT NULL,
  `guests` int(11) NOT NULL DEFAULT 1,
  `status` enum('pending','confirmed','checked_in','checked_out','cancelled') DEFAULT 'pending',
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `deposit_amount` decimal(12,2) DEFAULT 0.00,
  `balance_due` decimal(12,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `booking_number` (`booking_number`),
  KEY `customer_id` (`customer_id`),
  KEY `room_id` (`room_id`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_recipients`
--

DROP TABLE IF EXISTS `campaign_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign_recipients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `recipient` varchar(255) NOT NULL,
  `channel` enum('email','sms','whatsapp') NOT NULL,
  `status` enum('pending','sent','failed','opened','clicked','unsubscribed') DEFAULT 'pending',
  `sent_at` datetime DEFAULT NULL,
  `opened_at` datetime DEFAULT NULL,
  `clicked_at` datetime DEFAULT NULL,
  `error_message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_recipients`
--

LOCK TABLES `campaign_recipients` WRITE;
/*!40000 ALTER TABLE `campaign_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (3,'Beverages','Drinks and refreshments',1,'2025-11-27 13:48:24'),(4,'Housekeeping Supplies','Room and facility supplies',1,'2025-11-27 13:48:24');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chart_of_accounts`
--

DROP TABLE IF EXISTS `chart_of_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart_of_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_code` varchar(20) NOT NULL,
  `account_name` varchar(150) NOT NULL,
  `account_type` enum('asset','liability','equity','income','expense') NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_account_code` (`account_code`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `chart_of_accounts_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart_of_accounts`
--

LOCK TABLES `chart_of_accounts` WRITE;
/*!40000 ALTER TABLE `chart_of_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `chart_of_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_addresses`
--

DROP TABLE IF EXISTS `customer_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_addresses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `address_type` enum('billing','shipping','delivery') DEFAULT 'delivery',
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `delivery_instructions` text DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_city` (`city`),
  KEY `idx_postal_code` (`postal_code`),
  CONSTRAINT `customer_addresses_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_addresses`
--

LOCK TABLES `customer_addresses` WRITE;
/*!40000 ALTER TABLE `customer_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_delivery_preferences`
--

DROP TABLE IF EXISTS `customer_delivery_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_delivery_preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `preferred_instructions` text DEFAULT NULL,
  `preferred_delivery_window` varchar(100) DEFAULT NULL,
  `preferred_rider_notes` text DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_customer_delivery_pref` (`customer_id`),
  CONSTRAINT `customer_delivery_preferences_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_delivery_preferences`
--

LOCK TABLES `customer_delivery_preferences` WRITE;
/*!40000 ALTER TABLE `customer_delivery_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_delivery_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_loyalty_points`
--

DROP TABLE IF EXISTS `customer_loyalty_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_loyalty_points` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `program_id` int(10) unsigned NOT NULL,
  `points_earned` int(11) NOT NULL DEFAULT 0,
  `points_redeemed` int(11) NOT NULL DEFAULT 0,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_customer_program` (`customer_id`,`program_id`),
  KEY `fk_clp_program` (`program_id`),
  CONSTRAINT `fk_clp_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_clp_program` FOREIGN KEY (`program_id`) REFERENCES `loyalty_programs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_loyalty_points`
--

LOCK TABLES `customer_loyalty_points` WRITE;
/*!40000 ALTER TABLE `customer_loyalty_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_loyalty_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_preferences`
--

DROP TABLE IF EXISTS `customer_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `email_marketing` tinyint(1) DEFAULT 1,
  `sms_marketing` tinyint(1) DEFAULT 1,
  `whatsapp_marketing` tinyint(1) DEFAULT 1,
  `email_transactional` tinyint(1) DEFAULT 1,
  `sms_transactional` tinyint(1) DEFAULT 1,
  `whatsapp_transactional` tinyint(1) DEFAULT 1,
  `birthday_wishes` tinyint(1) DEFAULT 1,
  `promotional_offers` tinyint(1) DEFAULT 1,
  `newsletter` tinyint(1) DEFAULT 1,
  `preferred_channel` enum('email','sms','whatsapp') DEFAULT 'email',
  `unsubscribed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_preferences`
--

LOCK TABLES `customer_preferences` WRITE;
/*!40000 ALTER TABLE `customer_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `total_purchases` decimal(15,2) DEFAULT 0.00,
  `total_orders` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_phone` (`phone`),
  KEY `idx_customers_email` (`email`),
  KEY `idx_customers_phone` (`phone`),
  KEY `idx_customers_active` (`is_active`),
  KEY `idx_customers_deleted` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Walkin Customer','gordon@user.com','0700022022','kiressjka0',0.00,0,1,'2025-12-04 13:40:04','2025-12-04 13:40:04',NULL),(2,'grace','walking@user.com','+254701111111','central',0.00,0,1,'2025-12-04 13:40:56','2025-12-04 13:40:56',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deliveries`
--

DROP TABLE IF EXISTS `deliveries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deliveries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `rider_id` int(10) unsigned DEFAULT NULL,
  `pickup_address` text DEFAULT NULL,
  `delivery_address` text NOT NULL,
  `delivery_instructions` text DEFAULT NULL,
  `estimated_time` int(11) DEFAULT NULL,
  `actual_delivery_time` datetime DEFAULT NULL,
  `status` enum('pending','assigned','picked-up','in-transit','delivered','failed') DEFAULT 'pending',
  `customer_rating` int(11) DEFAULT NULL,
  `rider_rating` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `pickup_latitude` decimal(10,8) DEFAULT NULL,
  `pickup_longitude` decimal(11,8) DEFAULT NULL,
  `delivery_latitude` decimal(10,8) DEFAULT NULL,
  `delivery_longitude` decimal(11,8) DEFAULT NULL,
  `estimated_distance_km` float DEFAULT NULL,
  `actual_distance_km` float DEFAULT NULL,
  `estimated_delivery_time` datetime DEFAULT NULL,
  `pickup_time` datetime DEFAULT NULL,
  `delivery_proof_photo` varchar(255) DEFAULT NULL,
  `customer_signature` text DEFAULT NULL,
  `delivery_attempts` int(11) DEFAULT 0,
  `failed_reason` text DEFAULT NULL,
  `weather_conditions` varchar(50) DEFAULT NULL,
  `traffic_conditions` varchar(50) DEFAULT NULL,
  `assigned_at` datetime DEFAULT NULL,
  `picked_up_at` datetime DEFAULT NULL,
  `in_transit_at` datetime DEFAULT NULL,
  `delivery_notes` text DEFAULT NULL,
  `delivery_zone_id` int(10) unsigned DEFAULT NULL,
  `delivery_fee` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `idx_delivery_zone` (`delivery_zone_id`),
  KEY `idx_deliveries_status_created` (`status`,`created_at`),
  KEY `idx_delivery_lat_lng` (`delivery_latitude`,`delivery_longitude`),
  KEY `idx_deliveries_status` (`status`),
  KEY `idx_deliveries_rider` (`rider_id`),
  CONSTRAINT `deliveries_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `deliveries_ibfk_2` FOREIGN KEY (`rider_id`) REFERENCES `riders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliveries`
--

LOCK TABLES `deliveries` WRITE;
/*!40000 ALTER TABLE `deliveries` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliveries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_distance_cache`
--

DROP TABLE IF EXISTS `delivery_distance_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_distance_cache` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `origin_hash` char(64) NOT NULL,
  `destination_hash` char(64) NOT NULL,
  `origin_lat` decimal(10,8) NOT NULL,
  `origin_lng` decimal(11,8) NOT NULL,
  `destination_lat` decimal(10,8) NOT NULL,
  `destination_lng` decimal(11,8) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `distance_m` int(10) unsigned NOT NULL,
  `duration_s` int(10) unsigned DEFAULT NULL,
  `response_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_payload`)),
  `cached_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_origin_destination_hash` (`origin_hash`,`destination_hash`),
  KEY `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_distance_cache`
--

LOCK TABLES `delivery_distance_cache` WRITE;
/*!40000 ALTER TABLE `delivery_distance_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_distance_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_feedback`
--

DROP TABLE IF EXISTS `delivery_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_feedback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `delivery_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `rider_id` int(10) unsigned DEFAULT NULL,
  `rating` tinyint(3) unsigned NOT NULL,
  `comments` text DEFAULT NULL,
  `issues_reported` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`issues_reported`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `rider_id` (`rider_id`),
  KEY `idx_delivery_feedback_delivery` (`delivery_id`),
  KEY `idx_delivery_feedback_rating` (`rating`),
  CONSTRAINT `delivery_feedback_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delivery_feedback_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `delivery_feedback_ibfk_3` FOREIGN KEY (`rider_id`) REFERENCES `riders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_feedback`
--

LOCK TABLES `delivery_feedback` WRITE;
/*!40000 ALTER TABLE `delivery_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_metric_snapshots`
--

DROP TABLE IF EXISTS `delivery_metric_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_metric_snapshots` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `delivery_id` int(10) unsigned NOT NULL,
  `rider_id` int(10) unsigned DEFAULT NULL,
  `elapsed_minutes` int(10) unsigned DEFAULT NULL,
  `distance_km` decimal(8,2) DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_metric_delivery` (`delivery_id`),
  KEY `idx_metric_rider` (`rider_id`),
  CONSTRAINT `delivery_metric_snapshots_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_metric_snapshots`
--

LOCK TABLES `delivery_metric_snapshots` WRITE;
/*!40000 ALTER TABLE `delivery_metric_snapshots` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_metric_snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_metrics`
--

DROP TABLE IF EXISTS `delivery_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_metrics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `delivery_id` int(10) unsigned NOT NULL,
  `rider_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `distance_m` int(10) unsigned DEFAULT NULL,
  `duration_s` int(10) unsigned DEFAULT NULL,
  `pickup_delay_s` int(10) unsigned DEFAULT NULL,
  `delivery_delay_s` int(10) unsigned DEFAULT NULL,
  `weather` varchar(50) DEFAULT NULL,
  `traffic` varchar(50) DEFAULT NULL,
  `was_late` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `idx_delivery_metrics_delivery` (`delivery_id`),
  KEY `idx_delivery_metrics_rider` (`rider_id`),
  CONSTRAINT `delivery_metrics_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delivery_metrics_ibfk_2` FOREIGN KEY (`rider_id`) REFERENCES `riders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `delivery_metrics_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_metrics`
--

LOCK TABLES `delivery_metrics` WRITE;
/*!40000 ALTER TABLE `delivery_metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_metrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_notifications`
--

DROP TABLE IF EXISTS `delivery_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `delivery_id` int(10) unsigned NOT NULL,
  `recipient_type` enum('customer','rider','manager') NOT NULL,
  `channel` enum('sms','email','push','whatsapp') NOT NULL,
  `message` text NOT NULL,
  `status` enum('pending','sent','failed') NOT NULL DEFAULT 'pending',
  `sent_at` datetime DEFAULT NULL,
  `failure_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_delivery_notifications_delivery` (`delivery_id`),
  KEY `idx_delivery_notifications_status` (`status`),
  CONSTRAINT `delivery_notifications_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_notifications`
--

LOCK TABLES `delivery_notifications` WRITE;
/*!40000 ALTER TABLE `delivery_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_pricing_audit`
--

DROP TABLE IF EXISTS `delivery_pricing_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_pricing_audit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned DEFAULT NULL,
  `request_id` char(36) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `rule_id` int(10) unsigned DEFAULT NULL,
  `distance_m` int(10) unsigned DEFAULT NULL,
  `duration_s` int(10) unsigned DEFAULT NULL,
  `fee_applied` decimal(10,2) DEFAULT NULL,
  `api_calls` int(10) unsigned DEFAULT 0,
  `cache_hit` tinyint(1) DEFAULT 0,
  `fallback_used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_rule_id` (`rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_pricing_audit`
--

LOCK TABLES `delivery_pricing_audit` WRITE;
/*!40000 ALTER TABLE `delivery_pricing_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_pricing_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_pricing_rules`
--

DROP TABLE IF EXISTS `delivery_pricing_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_pricing_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(100) NOT NULL,
  `priority` int(10) unsigned NOT NULL DEFAULT 1,
  `distance_min_km` decimal(8,2) NOT NULL DEFAULT 0.00,
  `distance_max_km` decimal(8,2) DEFAULT NULL,
  `base_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `per_km_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `surcharge_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_distance_range` (`distance_min_km`,`distance_max_km`),
  KEY `idx_delivery_pricing_priority` (`priority`),
  KEY `idx_delivery_pricing_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_pricing_rules`
--

LOCK TABLES `delivery_pricing_rules` WRITE;
/*!40000 ALTER TABLE `delivery_pricing_rules` DISABLE KEYS */;
INSERT INTO `delivery_pricing_rules` VALUES (1,'Default 0-5km',1,0.00,5.00,50.00,0.00,0.00,'Initial default bracket',1,'2025-12-01 07:40:29','2025-12-01 07:40:29');
/*!40000 ALTER TABLE `delivery_pricing_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_routes`
--

DROP TABLE IF EXISTS `delivery_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_routes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `delivery_id` int(10) unsigned NOT NULL,
  `rider_id` int(10) unsigned NOT NULL,
  `route_snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`route_snapshot`)),
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_delivery_route_delivery` (`delivery_id`),
  KEY `idx_delivery_route_rider` (`rider_id`),
  CONSTRAINT `delivery_routes_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delivery_routes_ibfk_2` FOREIGN KEY (`rider_id`) REFERENCES `riders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_routes`
--

LOCK TABLES `delivery_routes` WRITE;
/*!40000 ALTER TABLE `delivery_routes` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_status_history`
--

DROP TABLE IF EXISTS `delivery_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_status_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `delivery_id` int(10) unsigned NOT NULL,
  `status` varchar(30) NOT NULL,
  `notes` text DEFAULT NULL,
  `photo_url` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_delivery_status_history_delivery` (`delivery_id`),
  KEY `idx_delivery_status_history_status` (`status`),
  CONSTRAINT `delivery_status_history_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delivery_status_history_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_status_history`
--

LOCK TABLES `delivery_status_history` WRITE;
/*!40000 ALTER TABLE `delivery_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_zones`
--

DROP TABLE IF EXISTS `delivery_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_zones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `polygon_coordinates` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`polygon_coordinates`)),
  `base_fee` decimal(10,2) DEFAULT 0.00,
  `per_km_fee` decimal(10,2) DEFAULT 0.00,
  `max_distance_km` decimal(6,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_delivery_zones_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_zones`
--

LOCK TABLES `delivery_zones` WRITE;
/*!40000 ALTER TABLE `delivery_zones` DISABLE KEYS */;
INSERT INTO `delivery_zones` VALUES (1,'City Core','0–5 km radius',NULL,1500.00,150.00,5.00,1,'2025-11-27 14:32:20','2025-11-27 14:32:20'),(2,'Metro Ring','5–15 km radius',NULL,2500.00,200.00,15.00,1,'2025-11-27 14:32:20','2025-11-27 14:32:20'),(3,'Outer Metro','15–30 km radius',NULL,4000.00,250.00,30.00,1,'2025-11-27 14:32:20','2025-11-27 14:32:20');
/*!40000 ALTER TABLE `delivery_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `demo_feedback`
--

DROP TABLE IF EXISTS `demo_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demo_feedback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `context_page` varchar(255) DEFAULT NULL,
  `rating` tinyint(4) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `comments` text NOT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `demo_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `demo_feedback`
--

LOCK TABLES `demo_feedback` WRITE;
/*!40000 ALTER TABLE `demo_feedback` DISABLE KEYS */;
INSERT INTO `demo_feedback` VALUES (1,NULL,'/wapos/feedback.php',5,'test@test.com','Test feedback',NULL,'2025-12-03 15:08:00');
/*!40000 ALTER TABLE `demo_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body_html` text NOT NULL,
  `body_text` text DEFAULT NULL,
  `template_type` enum('marketing','transactional','appreciation','reminder','alert') DEFAULT 'transactional',
  `variables` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`variables`)),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_time_clock`
--

DROP TABLE IF EXISTS `employee_time_clock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_time_clock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `clock_in_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `clock_out_at` timestamp NULL DEFAULT NULL,
  `break_start_at` timestamp NULL DEFAULT NULL,
  `break_end_at` timestamp NULL DEFAULT NULL,
  `total_break_minutes` int(11) DEFAULT 0,
  `scheduled_hours` decimal(5,2) DEFAULT NULL,
  `actual_hours` decimal(5,2) DEFAULT NULL,
  `overtime_hours` decimal(5,2) DEFAULT 0.00,
  `clock_in_note` varchar(255) DEFAULT NULL,
  `clock_out_note` varchar(255) DEFAULT NULL,
  `manager_note` varchar(255) DEFAULT NULL,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `status` enum('active','completed','adjusted','disputed') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_date` (`clock_in_at`),
  KEY `idx_status` (`status`),
  KEY `idx_location` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_time_clock`
--

LOCK TABLES `employee_time_clock` WRITE;
/*!40000 ALTER TABLE `employee_time_clock` DISABLE KEYS */;
INSERT INTO `employee_time_clock` VALUES (1,9,NULL,'2025-12-09 10:07:40',NULL,NULL,NULL,0,NULL,NULL,0.00,'',NULL,NULL,NULL,NULL,'active','2025-12-09 10:07:40','2025-12-09 10:07:40');
/*!40000 ALTER TABLE `employee_time_clock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense_categories`
--

DROP TABLE IF EXISTS `expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_categories`
--

LOCK TABLES `expense_categories` WRITE;
/*!40000 ALTER TABLE `expense_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `description` text DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `payment_method` enum('cash','card','mobile_money','bank_transfer','cheque','credit') DEFAULT 'cash',
  `reference` varchar(50) DEFAULT NULL,
  `receipt_number` varchar(50) DEFAULT NULL,
  `expense_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `location_id` (`location_id`),
  KEY `idx_date` (`expense_date`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `expenses_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `expense_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `expenses_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_received_notes`
--

DROP TABLE IF EXISTS `goods_received_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods_received_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `grn_number` varchar(50) NOT NULL,
  `purchase_order_id` int(10) unsigned DEFAULT NULL,
  `supplier_id` int(10) unsigned DEFAULT NULL,
  `received_date` date NOT NULL,
  `invoice_number` varchar(100) DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `status` enum('draft','completed','cancelled') DEFAULT 'draft',
  `received_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `grn_number` (`grn_number`),
  KEY `idx_grn_number` (`grn_number`),
  KEY `idx_po` (`purchase_order_id`),
  KEY `idx_status` (`status`),
  KEY `idx_received_date` (`received_date`),
  KEY `fk_grn_supplier` (`supplier_id`),
  KEY `fk_grn_user` (`received_by`),
  CONSTRAINT `fk_grn_po` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_grn_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_grn_user` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_received_notes`
--

LOCK TABLES `goods_received_notes` WRITE;
/*!40000 ALTER TABLE `goods_received_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `goods_received_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grn`
--

DROP TABLE IF EXISTS `grn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grn` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `supplier_id` int(10) unsigned NOT NULL,
  `reference` varchar(100) NOT NULL,
  `received_date` date NOT NULL,
  `total_items` int(10) unsigned DEFAULT 0,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `status` enum('pending','completed','cancelled') DEFAULT 'pending',
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_grn_supplier` (`supplier_id`),
  KEY `idx_grn_status` (`status`),
  CONSTRAINT `grn_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grn_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grn`
--

LOCK TABLES `grn` WRITE;
/*!40000 ALTER TABLE `grn` DISABLE KEYS */;
/*!40000 ALTER TABLE `grn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grn_items`
--

DROP TABLE IF EXISTS `grn_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grn_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `grn_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `ordered_quantity` decimal(10,2) DEFAULT 0.00,
  `received_quantity` decimal(10,2) NOT NULL,
  `unit_cost` decimal(15,2) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_grn_items_grn` (`grn_id`),
  KEY `idx_grn_items_product` (`product_id`),
  CONSTRAINT `grn_items_ibfk_1` FOREIGN KEY (`grn_id`) REFERENCES `grn` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grn_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grn_items`
--

LOCK TABLES `grn_items` WRITE;
/*!40000 ALTER TABLE `grn_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `grn_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_permissions`
--

DROP TABLE IF EXISTS `group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `module_id` int(10) unsigned NOT NULL,
  `action_id` int(10) unsigned NOT NULL,
  `is_granted` tinyint(1) DEFAULT 1,
  `conditions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`conditions`)),
  `granted_by` int(10) unsigned DEFAULT NULL,
  `granted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_group_permission` (`group_id`,`module_id`,`action_id`),
  KEY `module_id` (`module_id`),
  KEY `action_id` (`action_id`),
  KEY `granted_by` (`granted_by`),
  KEY `idx_group_permissions_group_id` (`group_id`),
  CONSTRAINT `group_permissions_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `permission_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_permissions_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `system_modules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_permissions_ibfk_3` FOREIGN KEY (`action_id`) REFERENCES `system_actions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_permissions_ibfk_4` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_permissions`
--

LOCK TABLES `group_permissions` WRITE;
/*!40000 ALTER TABLE `group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guest_login_attempts`
--

DROP TABLE IF EXISTS `guest_login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guest_login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) NOT NULL,
  `attempted_at` datetime NOT NULL,
  `success` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_username_time` (`username`,`attempted_at`),
  KEY `idx_ip_time` (`ip_address`,`attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest_login_attempts`
--

LOCK TABLES `guest_login_attempts` WRITE;
/*!40000 ALTER TABLE `guest_login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `guest_login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guest_portal_access`
--

DROP TABLE IF EXISTS `guest_portal_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guest_portal_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `access_token_hash` varchar(64) NOT NULL,
  `guest_name` varchar(100) NOT NULL,
  `room_number` varchar(20) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `email_encrypted` text DEFAULT NULL,
  `phone_encrypted` text DEFAULT NULL,
  `check_in_date` date NOT NULL,
  `check_out_date` date NOT NULL,
  `expires_at` datetime NOT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `login_count` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `revoked_at` datetime DEFAULT NULL,
  `revoked_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_username` (`username`),
  KEY `idx_room` (`room_number`),
  KEY `idx_booking` (`booking_id`),
  KEY `idx_active_expires` (`is_active`,`expires_at`),
  KEY `idx_token` (`access_token_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest_portal_access`
--

LOCK TABLES `guest_portal_access` WRITE;
/*!40000 ALTER TABLE `guest_portal_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `guest_portal_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guest_portal_activity_log`
--

DROP TABLE IF EXISTS `guest_portal_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guest_portal_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_access_id` int(11) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_guest` (`guest_access_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest_portal_activity_log`
--

LOCK TABLES `guest_portal_activity_log` WRITE;
/*!40000 ALTER TABLE `guest_portal_activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `guest_portal_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guest_portal_sessions`
--

DROP TABLE IF EXISTS `guest_portal_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guest_portal_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_access_id` int(11) NOT NULL,
  `session_token_hash` varchar(64) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `is_valid` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_token` (`session_token_hash`),
  KEY `idx_guest` (`guest_access_id`),
  KEY `idx_valid_expires` (`is_valid`,`expires_at`),
  CONSTRAINT `guest_portal_sessions_ibfk_1` FOREIGN KEY (`guest_access_id`) REFERENCES `guest_portal_access` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest_portal_sessions`
--

LOCK TABLES `guest_portal_sessions` WRITE;
/*!40000 ALTER TABLE `guest_portal_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `guest_portal_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `happy_hour_categories`
--

DROP TABLE IF EXISTS `happy_hour_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `happy_hour_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `happy_hour_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_hh_cat` (`happy_hour_id`,`category_id`),
  CONSTRAINT `happy_hour_categories_ibfk_1` FOREIGN KEY (`happy_hour_id`) REFERENCES `happy_hour_rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `happy_hour_categories`
--

LOCK TABLES `happy_hour_categories` WRITE;
/*!40000 ALTER TABLE `happy_hour_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `happy_hour_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `happy_hour_products`
--

DROP TABLE IF EXISTS `happy_hour_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `happy_hour_products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `happy_hour_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `special_price` decimal(15,2) DEFAULT NULL COMMENT 'Override price during happy hour',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_hh_prod` (`happy_hour_id`,`product_id`),
  CONSTRAINT `happy_hour_products_ibfk_1` FOREIGN KEY (`happy_hour_id`) REFERENCES `happy_hour_rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `happy_hour_products`
--

LOCK TABLES `happy_hour_products` WRITE;
/*!40000 ALTER TABLE `happy_hour_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `happy_hour_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `happy_hour_rules`
--

DROP TABLE IF EXISTS `happy_hour_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `happy_hour_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `days_of_week` varchar(100) DEFAULT 'all' COMMENT 'Comma-separated: monday,tuesday,etc or "all"',
  `valid_from` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `discount_type` enum('percent','fixed','bogo') DEFAULT 'percent',
  `discount_percent` decimal(5,2) DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `max_discount_amount` decimal(15,2) DEFAULT NULL COMMENT 'Cap on discount per item',
  `min_purchase_amount` decimal(15,2) DEFAULT NULL COMMENT 'Minimum spend to qualify',
  `max_uses_per_customer` int(11) DEFAULT NULL,
  `display_message` varchar(255) DEFAULT NULL,
  `banner_color` varchar(7) DEFAULT '#ffc107',
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_active` (`is_active`),
  KEY `idx_time` (`start_time`,`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `happy_hour_rules`
--

LOCK TABLES `happy_hour_rules` WRITE;
/*!40000 ALTER TABLE `happy_hour_rules` DISABLE KEYS */;
INSERT INTO `happy_hour_rules` VALUES (1,'Afternoon Happy Hour',NULL,'14:00:00','17:00:00','monday,tuesday,wednesday,thursday,friday',NULL,NULL,'percent',25.00,0.00,NULL,NULL,NULL,'­ƒì╗ 25% OFF all drinks!','#ffc107',1,NULL,'2025-12-09 09:09:27','2025-12-09 09:09:27'),(2,'Weekend Special',NULL,'12:00:00','15:00:00','saturday,sunday',NULL,NULL,'percent',30.00,0.00,NULL,NULL,NULL,'­ƒÄë Weekend Special - 30% OFF!','#ffc107',1,NULL,'2025-12-09 09:09:27','2025-12-09 09:09:27'),(3,'Late Night BOGO',NULL,'22:00:00','23:59:59','friday,saturday',NULL,NULL,'bogo',0.00,0.00,NULL,NULL,NULL,'­ƒì© Buy One Get One Free!','#ffc107',1,NULL,'2025-12-09 09:09:27','2025-12-09 09:09:27');
/*!40000 ALTER TABLE `happy_hour_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `happy_hour_usage`
--

DROP TABLE IF EXISTS `happy_hour_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `happy_hour_usage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `happy_hour_id` int(10) unsigned NOT NULL,
  `sale_id` int(10) unsigned DEFAULT NULL,
  `tab_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `discount_applied` decimal(15,2) NOT NULL,
  `original_amount` decimal(15,2) NOT NULL,
  `final_amount` decimal(15,2) NOT NULL,
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_happy_hour` (`happy_hour_id`),
  KEY `idx_date` (`applied_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `happy_hour_usage`
--

LOCK TABLES `happy_hour_usage` WRITE;
/*!40000 ALTER TABLE `happy_hour_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `happy_hour_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `housekeeping_inventory`
--

DROP TABLE IF EXISTS `housekeeping_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `housekeeping_inventory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `section` varchar(50) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `item_code` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `unit` varchar(50) DEFAULT 'pcs',
  `quantity_on_hand` decimal(15,4) DEFAULT 0.0000,
  `reorder_level` decimal(15,4) DEFAULT 0.0000,
  `cost_price` decimal(15,2) DEFAULT 0.00,
  `supplier` varchar(200) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `housekeeping_inventory`
--

LOCK TABLES `housekeeping_inventory` WRITE;
/*!40000 ALTER TABLE `housekeeping_inventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `housekeeping_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `housekeeping_inventory_log`
--

DROP TABLE IF EXISTS `housekeeping_inventory_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `housekeeping_inventory_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_id` int(10) unsigned NOT NULL,
  `transaction_type` enum('receipt','issue','adjustment','transfer','damage','return') NOT NULL,
  `quantity` decimal(15,4) NOT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` int(10) unsigned DEFAULT NULL,
  `from_location` varchar(100) DEFAULT NULL,
  `to_location` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `housekeeping_inventory_log`
--

LOCK TABLES `housekeeping_inventory_log` WRITE;
/*!40000 ALTER TABLE `housekeeping_inventory_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `housekeeping_inventory_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `housekeeping_laundry_batches`
--

DROP TABLE IF EXISTS `housekeeping_laundry_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `housekeeping_laundry_batches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(50) NOT NULL,
  `status` enum('pending','washing','drying','folding','completed','cancelled') DEFAULT 'pending',
  `item_count` int(11) DEFAULT 0,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `housekeeping_laundry_batches`
--

LOCK TABLES `housekeeping_laundry_batches` WRITE;
/*!40000 ALTER TABLE `housekeeping_laundry_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `housekeeping_laundry_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `housekeeping_linen`
--

DROP TABLE IF EXISTS `housekeeping_linen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `housekeeping_linen` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_id` int(10) unsigned NOT NULL,
  `linen_code` varchar(50) DEFAULT NULL,
  `status` enum('clean','in_use','dirty','washing','damaged','discarded') DEFAULT 'clean',
  `room_id` int(10) unsigned DEFAULT NULL,
  `last_washed_at` timestamp NULL DEFAULT NULL,
  `wash_count` int(11) DEFAULT 0,
  `condition_notes` text DEFAULT NULL,
  `acquired_date` date DEFAULT NULL,
  `discarded_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `housekeeping_linen`
--

LOCK TABLES `housekeeping_linen` WRITE;
/*!40000 ALTER TABLE `housekeeping_linen` DISABLE KEYS */;
/*!40000 ALTER TABLE `housekeeping_linen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `housekeeping_minibar_log`
--

DROP TABLE IF EXISTS `housekeeping_minibar_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `housekeeping_minibar_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_id` int(10) unsigned NOT NULL,
  `booking_id` int(10) unsigned DEFAULT NULL,
  `inventory_id` int(10) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `charged_to_folio` tinyint(1) DEFAULT 0,
  `folio_charge_id` int(10) unsigned DEFAULT NULL,
  `recorded_by` int(10) unsigned DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `housekeeping_minibar_log`
--

LOCK TABLES `housekeeping_minibar_log` WRITE;
/*!40000 ALTER TABLE `housekeeping_minibar_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `housekeeping_minibar_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `housekeeping_task_items`
--

DROP TABLE IF EXISTS `housekeeping_task_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `housekeeping_task_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `item_name` varchar(150) NOT NULL,
  `quantity_needed` decimal(10,2) NOT NULL DEFAULT 1.00,
  `quantity_used` decimal(10,2) NOT NULL DEFAULT 0.00,
  `unit` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_housekeeping_task_items_task` (`task_id`),
  CONSTRAINT `housekeeping_task_items_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `housekeeping_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `housekeeping_task_items`
--

LOCK TABLES `housekeeping_task_items` WRITE;
/*!40000 ALTER TABLE `housekeeping_task_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `housekeeping_task_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `housekeeping_task_logs`
--

DROP TABLE IF EXISTS `housekeeping_task_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `housekeeping_task_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `photo_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_housekeeping_task_logs_task` (`task_id`),
  KEY `idx_housekeeping_task_logs_status` (`status`),
  KEY `fk_housekeeping_task_logs_user` (`created_by`),
  CONSTRAINT `fk_housekeeping_task_logs_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `housekeeping_task_logs_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `housekeeping_tasks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `housekeeping_task_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `housekeeping_task_logs`
--

LOCK TABLES `housekeeping_task_logs` WRITE;
/*!40000 ALTER TABLE `housekeeping_task_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `housekeeping_task_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `housekeeping_tasks`
--

DROP TABLE IF EXISTS `housekeeping_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `housekeeping_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_id` int(10) unsigned DEFAULT NULL,
  `booking_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(150) NOT NULL,
  `notes` text DEFAULT NULL,
  `priority` enum('low','normal','high') NOT NULL DEFAULT 'normal',
  `status` enum('pending','in_progress','completed','cancelled') NOT NULL DEFAULT 'pending',
  `scheduled_date` date DEFAULT NULL,
  `scheduled_time` time DEFAULT NULL,
  `due_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `assigned_to` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_scheduled_date` (`scheduled_date`),
  KEY `fk_housekeeping_tasks_room` (`room_id`),
  KEY `fk_housekeeping_tasks_booking` (`booking_id`),
  KEY `fk_housekeeping_tasks_assigned` (`assigned_to`),
  KEY `idx_housekeeping_status` (`status`),
  CONSTRAINT `fk_housekeeping_tasks_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_housekeeping_tasks_booking` FOREIGN KEY (`booking_id`) REFERENCES `room_bookings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_housekeeping_tasks_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `housekeeping_tasks`
--

LOCK TABLES `housekeeping_tasks` WRITE;
/*!40000 ALTER TABLE `housekeeping_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `housekeeping_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_categories`
--

DROP TABLE IF EXISTS `inventory_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `legacy_category_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `module_scope` enum('retail','restaurant','housekeeping','maintenance','general') DEFAULT 'general',
  `is_consumable` tinyint(1) DEFAULT 0,
  `track_expiry` tinyint(1) DEFAULT 0,
  `track_wastage` tinyint(1) DEFAULT 0,
  `description` text DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_legacy_category` (`legacy_category_id`),
  KEY `idx_inventory_categories_parent` (`parent_id`),
  KEY `idx_scope` (`module_scope`),
  CONSTRAINT `inventory_categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `inventory_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_categories`
--

LOCK TABLES `inventory_categories` WRITE;
/*!40000 ALTER TABLE `inventory_categories` DISABLE KEYS */;
INSERT INTO `inventory_categories` VALUES (1,3,'Beverages','retail',0,0,0,NULL,NULL,1,'2025-12-03 07:27:49','2025-12-03 07:27:49'),(2,4,'Housekeeping Supplies','retail',0,0,0,NULL,NULL,1,'2025-12-03 07:55:32','2025-12-03 07:55:32');
/*!40000 ALTER TABLE `inventory_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_consumption_events`
--

DROP TABLE IF EXISTS `inventory_consumption_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_consumption_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_item_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `source_module` enum('retail','restaurant','housekeeping','maintenance','general') DEFAULT 'general',
  `source_reference` varchar(120) DEFAULT NULL,
  `quantity` decimal(18,4) NOT NULL,
  `wastage_quantity` decimal(18,4) DEFAULT 0.0000,
  `reason` enum('sale','task','maintenance','wastage','adjustment') DEFAULT 'sale',
  `notes` varchar(255) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_item` (`inventory_item_id`),
  KEY `idx_source` (`source_module`,`source_reference`),
  CONSTRAINT `fk_inventory_consumption_item` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_consumption_events`
--

LOCK TABLES `inventory_consumption_events` WRITE;
/*!40000 ALTER TABLE `inventory_consumption_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_consumption_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `module_scope` enum('retail','restaurant','housekeeping','maintenance','general') DEFAULT 'general',
  `unit` varchar(20) DEFAULT 'pcs',
  `current_stock` decimal(18,4) DEFAULT 0.0000,
  `min_stock_level` decimal(18,4) DEFAULT 0.0000,
  `reorder_level` decimal(18,4) DEFAULT 0.0000,
  `reorder_quantity` decimal(18,4) DEFAULT 0.0000,
  `track_expiry` tinyint(1) DEFAULT 0,
  `track_wastage` tinyint(1) DEFAULT 0,
  `cost_price` decimal(15,4) DEFAULT 0.0000,
  `last_cost` decimal(15,4) DEFAULT 0.0000,
  `last_count_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_product_id` (`product_id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_scope` (`module_scope`),
  KEY `idx_inventory_sku` (`sku`),
  KEY `idx_inventory_active` (`is_active`),
  KEY `idx_inventory_deleted` (`deleted_at`),
  CONSTRAINT `fk_inventory_items_category` FOREIGN KEY (`category_id`) REFERENCES `inventory_categories` (`id`),
  CONSTRAINT `fk_inventory_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
INSERT INTO `inventory_items` VALUES (1,1,1,'Bottled Water 500ml','BW-500','retail','pcs',88.0000,10.0000,0.0000,0.0000,0,0,20.0000,20.0000,NULL,1,'2025-12-03 07:27:49','2025-12-03 08:07:20',NULL),(2,2,2,'Room Linen Set','RL-SET','retail','pcs',14.0000,10.0000,0.0000,0.0000,0,0,1500.0000,1500.0000,NULL,1,'2025-12-03 07:55:32','2025-12-03 08:09:27',NULL);
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_stock_ledger`
--

DROP TABLE IF EXISTS `inventory_stock_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_stock_ledger` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_item_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `movement_type` enum('grn','sale','adjustment','transfer','consumption','wastage','manual') NOT NULL,
  `direction` enum('in','out') NOT NULL,
  `quantity` decimal(18,4) NOT NULL,
  `cost_price` decimal(15,4) DEFAULT 0.0000,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` int(10) unsigned DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `source_module` enum('retail','restaurant','housekeeping','maintenance','general','api') DEFAULT 'general',
  `notes` varchar(255) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_item` (`inventory_item_id`),
  KEY `idx_reference` (`reference_type`,`reference_id`),
  KEY `idx_created` (`created_at`),
  KEY `fk_inventory_ledger_product` (`product_id`),
  CONSTRAINT `fk_inventory_ledger_item` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_inventory_ledger_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_stock_ledger`
--

LOCK TABLES `inventory_stock_ledger` WRITE;
/*!40000 ALTER TABLE `inventory_stock_ledger` DISABLE KEYS */;
INSERT INTO `inventory_stock_ledger` VALUES (1,1,1,'sale','out',3.0000,20.0000,'sale',11,'SAL-20251203-0010','retail','Sale #SAL-20251203-0010',1,'2025-12-03 07:27:49'),(2,1,1,'sale','out',3.0000,20.0000,'sale',12,'SAL-20251203-0011','retail','Sale #SAL-20251203-0011',1,'2025-12-03 07:28:31'),(3,1,1,'sale','out',3.0000,20.0000,'sale',13,'SAL-20251203-0012','retail','Sale #SAL-20251203-0012',1,'2025-12-03 07:52:44'),(4,2,2,'sale','out',3.0000,1500.0000,'sale',14,'SAL-20251203-0013','retail','Sale #SAL-20251203-0013',1,'2025-12-03 07:55:32'),(5,1,1,'sale','out',3.0000,20.0000,'sale',15,'SAL-20251203-0014','retail','Sale #SAL-20251203-0014',1,'2025-12-03 08:07:20'),(6,2,2,'sale','out',3.0000,1500.0000,'sale',16,'SAL-20251203-0015','retail','Sale #SAL-20251203-0015',1,'2025-12-03 08:09:27');
/*!40000 ALTER TABLE `inventory_stock_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_entries`
--

DROP TABLE IF EXISTS `journal_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entry_number` varchar(50) NOT NULL,
  `source` varchar(50) DEFAULT NULL,
  `source_id` int(11) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `entry_date` date NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `total_debit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_credit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `reference_number` varchar(100) DEFAULT NULL,
  `status` enum('draft','posted','voided') DEFAULT 'draft',
  `period_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `posted_by` int(10) unsigned DEFAULT NULL,
  `posted_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_entry_number` (`entry_number`),
  KEY `idx_entry_date` (`entry_date`),
  KEY `posted_by` (`posted_by`),
  CONSTRAINT `journal_entries_ibfk_1` FOREIGN KEY (`posted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_entries`
--

LOCK TABLES `journal_entries` WRITE;
/*!40000 ALTER TABLE `journal_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_entry_lines`
--

DROP TABLE IF EXISTS `journal_entry_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_entry_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `journal_entry_id` bigint(20) unsigned NOT NULL,
  `account_id` int(10) unsigned DEFAULT NULL,
  `line_number` int(10) unsigned NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `debit_amount` decimal(15,2) DEFAULT 0.00,
  `credit_amount` decimal(15,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_entry_line` (`journal_entry_id`,`line_number`),
  CONSTRAINT `journal_entry_lines_ibfk_1` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_entry_lines`
--

LOCK TABLES `journal_entry_lines` WRITE;
/*!40000 ALTER TABLE `journal_entry_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal_entry_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_lines`
--

DROP TABLE IF EXISTS `journal_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_lines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `journal_entry_id` bigint(20) unsigned NOT NULL,
  `account_id` int(10) unsigned NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `debit_amount` decimal(15,2) DEFAULT 0.00,
  `credit_amount` decimal(15,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_journal_lines_entry` (`journal_entry_id`),
  KEY `idx_journal_lines_account` (`account_id`),
  KEY `idx_jl_account` (`account_id`),
  KEY `idx_jl_entry` (`journal_entry_id`),
  CONSTRAINT `journal_lines_ibfk_1` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `journal_lines_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_lines`
--

LOCK TABLES `journal_lines` WRITE;
/*!40000 ALTER TABLE `journal_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal_lines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_stock`
--

DROP TABLE IF EXISTS `location_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_stock` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `current_stock` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `reserved_stock` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `reorder_level` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `reorder_quantity` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `last_restocked_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_location_product` (`location_id`,`product_id`),
  KEY `idx_location_stock_location` (`location_id`),
  KEY `idx_location_stock_product` (`product_id`),
  CONSTRAINT `location_stock_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `location_stock_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_stock`
--

LOCK TABLES `location_stock` WRITE;
/*!40000 ALTER TABLE `location_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `manager_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_locations_manager` (`manager_id`),
  CONSTRAINT `fk_locations_manager` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (13,'Flagship Hotel',NULL,'International Way 1, Nairobi, Kenya',NULL,NULL,'+254-700-111-111','flagship@waesta.com',NULL,1,'active','2025-11-27 13:48:24','2025-11-27 13:48:24'),(14,'Downtown Bistro',NULL,'CBD Plaza 5, Nairobi, Kenya',NULL,NULL,'+254-700-222-222','downtown@waesta.com',NULL,1,'active','2025-11-27 13:48:24','2025-11-27 13:48:24');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_programs`
--

DROP TABLE IF EXISTS `loyalty_programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_programs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `points_per_dollar` decimal(10,4) NOT NULL DEFAULT 1.0000,
  `redemption_rate` decimal(10,4) NOT NULL DEFAULT 0.0100,
  `min_points_redemption` int(10) unsigned NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_programs`
--

LOCK TABLES `loyalty_programs` WRITE;
/*!40000 ALTER TABLE `loyalty_programs` DISABLE KEYS */;
INSERT INTO `loyalty_programs` VALUES (1,'Default Loyalty Program','Default chain-wide loyalty program',1.0000,0.0100,100,1,'2025-11-27 05:38:45','2025-11-27 14:33:13');
/*!40000 ALTER TABLE `loyalty_programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyalty_transactions`
--

DROP TABLE IF EXISTS `loyalty_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `program_id` int(10) unsigned NOT NULL,
  `transaction_type` enum('earn','redeem','adjust','expire') NOT NULL,
  `points` int(11) NOT NULL,
  `sale_id` int(10) unsigned DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `idx_loyalty_transactions_customer` (`customer_id`),
  KEY `idx_loyalty_transactions_program` (`program_id`),
  CONSTRAINT `loyalty_transactions_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loyalty_transactions_ibfk_2` FOREIGN KEY (`program_id`) REFERENCES `loyalty_programs` (`id`),
  CONSTRAINT `loyalty_transactions_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_transactions`
--

LOCK TABLES `loyalty_transactions` WRITE;
/*!40000 ALTER TABLE `loyalty_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `loyalty_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenance_request_logs`
--

DROP TABLE IF EXISTS `maintenance_request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maintenance_request_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `request_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status` enum('open','assigned','in_progress','on_hold','resolved','closed') NOT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_maintenance_request_logs_request` (`request_id`),
  KEY `idx_maintenance_request_logs_status` (`status`),
  KEY `fk_maintenance_logs_user` (`created_by`),
  CONSTRAINT `fk_maintenance_logs_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `maintenance_request_logs_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `maintenance_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `maintenance_request_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance_request_logs`
--

LOCK TABLES `maintenance_request_logs` WRITE;
/*!40000 ALTER TABLE `maintenance_request_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenance_request_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenance_requests`
--

DROP TABLE IF EXISTS `maintenance_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maintenance_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_id` int(10) unsigned DEFAULT NULL,
  `booking_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `priority` enum('low','normal','high') NOT NULL DEFAULT 'normal',
  `status` enum('open','assigned','in_progress','on_hold','resolved','closed') NOT NULL DEFAULT 'open',
  `reporter_type` varchar(40) NOT NULL DEFAULT 'staff',
  `reporter_name` varchar(120) DEFAULT NULL,
  `reporter_contact` varchar(120) DEFAULT NULL,
  `tracking_code` varchar(16) DEFAULT NULL,
  `reference_code` varchar(60) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `assigned_to` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`),
  KEY `idx_due_date` (`due_date`),
  KEY `fk_maintenance_requests_room` (`room_id`),
  KEY `fk_maintenance_requests_booking` (`booking_id`),
  KEY `fk_maintenance_requests_assigned` (`assigned_to`),
  KEY `fk_maintenance_requests_created` (`created_by`),
  KEY `idx_maintenance_status` (`status`),
  KEY `idx_maintenance_priority` (`priority`),
  CONSTRAINT `fk_maintenance_requests_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_maintenance_requests_booking` FOREIGN KEY (`booking_id`) REFERENCES `room_bookings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_maintenance_requests_created` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_maintenance_requests_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance_requests`
--

LOCK TABLES `maintenance_requests` WRITE;
/*!40000 ALTER TABLE `maintenance_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenance_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_campaigns`
--

DROP TABLE IF EXISTS `marketing_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_campaigns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `channel` enum('email','sms','whatsapp','all') DEFAULT 'email',
  `campaign_type` enum('promotional','newsletter','announcement','seasonal','loyalty') DEFAULT 'promotional',
  `subject` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `target_segment` enum('all','active','inactive','high_value','new','birthday','custom') DEFAULT 'all',
  `target_criteria` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`target_criteria`)),
  `scheduled_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `status` enum('draft','scheduled','running','completed','cancelled') DEFAULT 'draft',
  `total_recipients` int(10) unsigned DEFAULT 0,
  `sent_count` int(10) unsigned DEFAULT 0,
  `failed_count` int(10) unsigned DEFAULT 0,
  `open_count` int(10) unsigned DEFAULT 0,
  `click_count` int(10) unsigned DEFAULT 0,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_campaigns`
--

LOCK TABLES `marketing_campaigns` WRITE;
/*!40000 ALTER TABLE `marketing_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  `executed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_migration` (`migration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modifiers`
--

DROP TABLE IF EXISTS `modifiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modifiers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `applies_to` enum('product','category') DEFAULT 'product',
  `product_id` int(10) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `price_adjustment` decimal(10,2) DEFAULT 0.00,
  `is_required` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `modifiers_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `modifiers_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modifiers`
--

LOCK TABLES `modifiers` WRITE;
/*!40000 ALTER TABLE `modifiers` DISABLE KEYS */;
/*!40000 ALTER TABLE `modifiers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_actions`
--

DROP TABLE IF EXISTS `module_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(10) unsigned NOT NULL,
  `action_id` int(10) unsigned NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_module_action` (`module_id`,`action_id`),
  KEY `action_id` (`action_id`),
  CONSTRAINT `module_actions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `system_modules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `module_actions_ibfk_2` FOREIGN KEY (`action_id`) REFERENCES `system_actions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2679 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_actions`
--

LOCK TABLES `module_actions` WRITE;
/*!40000 ALTER TABLE `module_actions` DISABLE KEYS */;
INSERT INTO `module_actions` VALUES (1,6,12,0,'2025-12-03 13:58:04'),(2,12,33,0,'2025-12-03 13:58:04'),(3,11,30,0,'2025-12-03 13:58:04'),(4,12,29,0,'2025-12-03 13:58:04'),(5,11,27,0,'2025-12-03 13:58:04'),(6,6,15,0,'2025-12-03 13:58:04'),(7,10,2,1,'2025-12-03 13:58:04'),(8,8,2,1,'2025-12-03 13:58:04'),(9,5,2,1,'2025-12-03 13:58:04'),(10,13,2,1,'2025-12-03 13:58:04'),(11,15,2,1,'2025-12-03 13:58:04'),(12,14,2,1,'2025-12-03 13:58:04'),(13,2,2,1,'2025-12-03 13:58:04'),(14,6,2,1,'2025-12-03 13:58:04'),(15,3,2,1,'2025-12-03 13:58:04'),(16,4,2,1,'2025-12-03 13:58:04'),(17,11,2,1,'2025-12-03 13:58:04'),(18,13,32,0,'2025-12-03 13:58:04'),(19,8,20,0,'2025-12-03 13:58:04'),(20,2,20,0,'2025-12-03 13:58:04'),(21,4,20,0,'2025-12-03 13:58:04'),(22,10,4,0,'2025-12-03 13:58:04'),(23,8,4,0,'2025-12-03 13:58:04'),(24,5,4,0,'2025-12-03 13:58:04'),(25,13,4,0,'2025-12-03 13:58:04'),(26,15,4,0,'2025-12-03 13:58:04'),(27,14,4,0,'2025-12-03 13:58:04'),(28,2,4,0,'2025-12-03 13:58:04'),(29,6,4,0,'2025-12-03 13:58:04'),(30,3,4,0,'2025-12-03 13:58:04'),(31,4,4,0,'2025-12-03 13:58:04'),(32,11,4,0,'2025-12-03 13:58:04'),(33,2,7,0,'2025-12-03 13:58:04'),(34,10,24,0,'2025-12-03 13:58:04'),(35,8,24,0,'2025-12-03 13:58:04'),(36,1,24,0,'2025-12-03 13:58:04'),(37,5,24,0,'2025-12-03 13:58:04'),(38,13,24,0,'2025-12-03 13:58:04'),(39,15,24,0,'2025-12-03 13:58:04'),(40,14,24,0,'2025-12-03 13:58:04'),(41,2,24,0,'2025-12-03 13:58:04'),(42,6,24,0,'2025-12-03 13:58:04'),(43,9,24,0,'2025-12-03 13:58:04'),(44,3,24,0,'2025-12-03 13:58:04'),(45,4,24,0,'2025-12-03 13:58:04'),(46,7,24,0,'2025-12-03 13:58:04'),(47,11,24,0,'2025-12-03 13:58:04'),(48,10,23,0,'2025-12-03 13:58:04'),(49,9,23,0,'2025-12-03 13:58:04'),(50,7,23,0,'2025-12-03 13:58:04'),(51,12,34,0,'2025-12-03 13:58:04'),(52,3,17,0,'2025-12-03 13:58:04'),(53,2,11,0,'2025-12-03 13:58:04'),(54,5,31,0,'2025-12-03 13:58:04'),(55,13,31,0,'2025-12-03 13:58:04'),(56,9,31,0,'2025-12-03 13:58:04'),(57,8,19,0,'2025-12-03 13:58:04'),(58,2,19,0,'2025-12-03 13:58:04'),(59,2,9,0,'2025-12-03 13:58:04'),(60,11,26,0,'2025-12-03 13:58:04'),(61,3,16,0,'2025-12-03 13:58:04'),(62,2,8,0,'2025-12-03 13:58:04'),(63,10,25,0,'2025-12-03 13:58:04'),(64,8,25,0,'2025-12-03 13:58:04'),(65,1,25,0,'2025-12-03 13:58:04'),(66,5,25,0,'2025-12-03 13:58:04'),(67,2,25,0,'2025-12-03 13:58:04'),(68,6,25,0,'2025-12-03 13:58:04'),(69,9,25,0,'2025-12-03 13:58:04'),(70,3,25,0,'2025-12-03 13:58:04'),(71,4,25,0,'2025-12-03 13:58:04'),(72,7,25,0,'2025-12-03 13:58:04'),(73,6,14,0,'2025-12-03 13:58:04'),(74,2,6,0,'2025-12-03 13:58:04'),(75,7,6,0,'2025-12-03 13:58:04'),(76,8,21,0,'2025-12-03 13:58:04'),(77,5,21,0,'2025-12-03 13:58:04'),(78,2,21,0,'2025-12-03 13:58:04'),(79,3,21,0,'2025-12-03 13:58:04'),(80,4,21,0,'2025-12-03 13:58:04'),(81,2,10,0,'2025-12-03 13:58:04'),(82,12,28,0,'2025-12-03 13:58:04'),(83,14,18,0,'2025-12-03 13:58:04'),(84,3,18,0,'2025-12-03 13:58:04'),(85,10,35,0,'2025-12-03 13:58:04'),(86,12,35,0,'2025-12-03 13:58:04'),(87,13,13,0,'2025-12-03 13:58:04'),(88,6,13,0,'2025-12-03 13:58:04'),(89,10,3,1,'2025-12-03 13:58:04'),(90,8,3,1,'2025-12-03 13:58:04'),(91,5,3,1,'2025-12-03 13:58:04'),(92,13,3,1,'2025-12-03 13:58:04'),(93,15,3,1,'2025-12-03 13:58:04'),(94,14,3,1,'2025-12-03 13:58:04'),(95,2,3,1,'2025-12-03 13:58:04'),(96,6,3,1,'2025-12-03 13:58:04'),(97,3,3,1,'2025-12-03 13:58:04'),(98,4,3,1,'2025-12-03 13:58:04'),(99,12,3,1,'2025-12-03 13:58:04'),(100,11,3,1,'2025-12-03 13:58:04'),(101,10,1,1,'2025-12-03 13:58:04'),(102,8,1,1,'2025-12-03 13:58:04'),(103,1,1,1,'2025-12-03 13:58:04'),(104,5,1,1,'2025-12-03 13:58:04'),(105,13,1,1,'2025-12-03 13:58:04'),(106,15,1,1,'2025-12-03 13:58:04'),(107,14,1,1,'2025-12-03 13:58:04'),(108,2,1,1,'2025-12-03 13:58:04'),(109,6,1,1,'2025-12-03 13:58:04'),(110,9,1,1,'2025-12-03 13:58:04'),(111,3,1,1,'2025-12-03 13:58:04'),(112,4,1,1,'2025-12-03 13:58:04'),(113,7,1,1,'2025-12-03 13:58:04'),(114,12,1,1,'2025-12-03 13:58:04'),(115,11,1,1,'2025-12-03 13:58:04'),(116,10,22,0,'2025-12-03 13:58:04'),(117,9,22,0,'2025-12-03 13:58:04'),(118,7,22,0,'2025-12-03 13:58:04'),(119,2,5,0,'2025-12-03 13:58:04'),(120,3,5,0,'2025-12-03 13:58:04'),(121,7,5,0,'2025-12-03 13:58:04'),(129,31,1,1,'2025-12-03 13:59:52'),(130,31,2,1,'2025-12-03 13:59:52'),(131,31,3,1,'2025-12-03 13:59:52'),(132,31,4,0,'2025-12-03 13:59:52'),(133,31,21,0,'2025-12-03 13:59:52'),(134,31,20,0,'2025-12-03 13:59:52'),(135,32,1,1,'2025-12-03 13:59:52'),(136,32,2,1,'2025-12-03 13:59:52'),(137,32,3,1,'2025-12-03 13:59:52'),(138,32,4,0,'2025-12-03 13:59:52'),(139,33,1,1,'2025-12-03 13:59:52'),(140,33,2,1,'2025-12-03 13:59:52'),(141,33,3,1,'2025-12-03 13:59:52'),(142,33,4,0,'2025-12-03 13:59:52'),(143,34,1,1,'2025-12-03 13:59:52'),(144,34,2,1,'2025-12-03 13:59:52'),(145,34,3,1,'2025-12-03 13:59:52'),(146,34,21,0,'2025-12-03 13:59:52'),(147,35,1,1,'2025-12-03 13:59:52'),(148,35,2,1,'2025-12-03 13:59:52'),(149,35,3,1,'2025-12-03 13:59:52'),(150,35,4,0,'2025-12-03 13:59:52'),(151,35,6,0,'2025-12-03 13:59:52'),(152,35,7,0,'2025-12-03 13:59:52'),(153,36,1,1,'2025-12-03 13:59:52'),(154,36,2,1,'2025-12-03 13:59:52'),(155,36,3,1,'2025-12-03 13:59:52'),(156,36,4,0,'2025-12-03 13:59:52'),(157,36,24,0,'2025-12-03 13:59:52'),(158,37,1,1,'2025-12-03 13:59:52'),(159,37,2,1,'2025-12-03 13:59:52'),(160,37,3,1,'2025-12-03 13:59:52'),(161,37,4,0,'2025-12-03 13:59:52'),(162,37,21,0,'2025-12-03 13:59:52'),(163,38,1,1,'2025-12-03 13:59:52'),(164,38,3,1,'2025-12-03 13:59:52'),(165,38,30,0,'2025-12-03 13:59:52'),(166,39,1,1,'2025-12-03 13:59:52'),(167,39,2,1,'2025-12-03 13:59:52'),(168,39,3,1,'2025-12-03 13:59:52'),(169,39,4,0,'2025-12-03 13:59:52'),(170,40,1,1,'2025-12-03 13:59:52'),(171,40,22,0,'2025-12-03 13:59:52'),(172,40,23,0,'2025-12-03 13:59:52'),(173,40,24,0,'2025-12-03 13:59:52'),(174,41,1,1,'2025-12-03 13:59:52'),(175,41,2,1,'2025-12-03 13:59:52'),(176,41,3,1,'2025-12-03 13:59:52'),(177,41,4,0,'2025-12-03 13:59:52'),(178,41,24,0,'2025-12-03 13:59:52');
/*!40000 ALTER TABLE `module_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_logs`
--

DROP TABLE IF EXISTS `notification_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `channel` enum('email','sms','whatsapp') NOT NULL,
  `recipient` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `notification_type` enum('marketing','transactional','appreciation','reminder','alert') DEFAULT 'transactional',
  `customer_id` int(10) unsigned DEFAULT NULL,
  `status` enum('pending','sent','failed','bounced') DEFAULT 'pending',
  `response` text DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_channel` (`channel`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`notification_type`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_logs`
--

LOCK TABLES `notification_logs` WRITE;
/*!40000 ALTER TABLE `notification_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `modifiers_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`modifiers_data`)),
  `special_instructions` text DEFAULT NULL,
  `status` enum('pending','preparing','ready','served') DEFAULT 'pending',
  `total_price` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_status` (`status`),
  KEY `idx_order_items_status` (`status`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (1,1,2,'Room Linen Set',1,3200.00,'[]','','ready',3200.00),(2,2,2,'Room Linen Set',1,3200.00,'[]','','ready',3200.00),(3,3,2,'Room Linen Set',1,3200.00,'[]','','ready',3200.00),(4,4,2,'Room Linen Set',1,3200.00,'[]','','preparing',3200.00),(5,5,1,'Bottled Water 500ml',1,60.00,'[]','','pending',60.00),(6,6,2,'Room Linen Set',1,3200.00,'[]','','pending',3200.00),(7,7,1,'Bottled Water 500ml',1,60.00,'[]','','pending',60.00),(8,8,2,'Room Linen Set',1,3200.00,'[]','','pending',3200.00),(9,9,2,'Room Linen Set',1,3200.00,'[]','','pending',3200.00);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_meta`
--

DROP TABLE IF EXISTS `order_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `meta_key` varchar(100) NOT NULL,
  `meta_value` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_order_meta_order` (`order_id`),
  KEY `idx_order_meta_key` (`meta_key`),
  CONSTRAINT `fk_order_meta_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_meta`
--

LOCK TABLES `order_meta` WRITE;
/*!40000 ALTER TABLE `order_meta` DISABLE KEYS */;
INSERT INTO `order_meta` VALUES (1,1,'promotion_summary','{\"total_discount\":0,\"applied\":[]}','2025-12-02 12:38:22'),(2,2,'promotion_summary','{\"total_discount\":0,\"applied\":[]}','2025-12-02 13:01:20'),(3,3,'promotion_summary','{\"total_discount\":0,\"applied\":[]}','2025-12-02 13:17:27'),(4,4,'promotion_summary','{\"total_discount\":0,\"applied\":[]}','2025-12-02 13:21:19'),(5,5,'promotion_summary','{\"total_discount\":0,\"applied\":[]}','2025-12-02 13:21:50'),(6,6,'promotion_summary','{\"total_discount\":0,\"applied\":[]}','2025-12-02 13:23:32'),(7,7,'promotion_summary','{\"total_discount\":0,\"applied\":[]}','2025-12-02 13:27:13'),(8,8,'promotion_summary','{\"total_discount\":0,\"applied\":[]}','2025-12-02 13:32:08'),(9,9,'promotion_summary','{\"total_discount\":0,\"applied\":[]}','2025-12-02 13:49:15');
/*!40000 ALTER TABLE `order_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_payments`
--

DROP TABLE IF EXISTS `order_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `payment_method` enum('cash','card','mobile_money','bank_transfer','voucher','split') NOT NULL DEFAULT 'cash',
  `amount` decimal(15,2) NOT NULL,
  `tip_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `reference_number` varchar(100) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `processor_response` text DEFAULT NULL,
  `paid_at` datetime NOT NULL DEFAULT current_timestamp(),
  `recorded_by_user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `recorded_by` (`recorded_by_user_id`),
  KEY `idx_order_payments_order` (`order_id`),
  KEY `idx_order_payments_method` (`payment_method`),
  CONSTRAINT `order_payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_payments_ibfk_2` FOREIGN KEY (`recorded_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_payments`
--

LOCK TABLES `order_payments` WRITE;
/*!40000 ALTER TABLE `order_payments` DISABLE KEYS */;
INSERT INTO `order_payments` VALUES (1,9,'cash',3712.00,0.00,'{\"amount_received\":4000,\"change_amount\":288}',NULL,NULL,NULL,'2025-12-02 16:49:18',1,'2025-12-02 13:49:18','2025-12-02 13:49:18');
/*!40000 ALTER TABLE `order_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `order_type` enum('dine-in','takeout','delivery','retail') NOT NULL,
  `table_id` int(10) unsigned DEFAULT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `delivery_address` text DEFAULT NULL,
  `delivery_instructions` text DEFAULT NULL,
  `rider_id` int(10) unsigned DEFAULT NULL,
  `status` enum('pending','preparing','ready','delivered','completed','cancelled') DEFAULT 'pending',
  `subtotal` decimal(15,2) NOT NULL,
  `tax_amount` decimal(15,2) DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `delivery_fee` decimal(10,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL,
  `tip_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_status` enum('pending','paid','partial','refunded') DEFAULT 'pending',
  `user_id` int(10) unsigned NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `user_id` (`user_id`),
  KEY `idx_order_type` (`order_type`),
  KEY `idx_status` (`status`),
  KEY `idx_date` (`created_at`),
  KEY `idx_completed_at` (`completed_at`),
  KEY `idx_orders_created_at` (`created_at`),
  KEY `idx_orders_status` (`status`),
  KEY `idx_orders_table_id` (`table_id`),
  KEY `idx_orders_customer_id` (`customer_id`),
  KEY `idx_orders_deleted` (`deleted_at`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`table_id`) REFERENCES `restaurant_tables` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'ORD-20251202-EAAC54','dine-in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'completed',3200.00,512.00,0.00,0.00,3712.00,0.00,0.00,'cash','pending',1,NULL,'2025-12-02 12:38:22','2025-12-03 08:57:29','2025-12-03 11:57:29',NULL),(2,'ORD-20251202-0797D7','dine-in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'completed',3200.00,512.00,0.00,0.00,3712.00,0.00,0.00,'cash','pending',1,NULL,'2025-12-02 13:01:20','2025-12-03 08:57:33','2025-12-03 11:57:33',NULL),(3,'ORD-20251202-7DEDC0','dine-in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'completed',3200.00,512.00,0.00,0.00,3712.00,0.00,0.00,'cash','pending',1,NULL,'2025-12-02 13:17:27','2025-12-03 08:57:38','2025-12-03 11:57:38',NULL),(4,'ORD-20251202-F94F32','dine-in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',3200.00,512.00,0.00,0.00,3712.00,0.00,0.00,'cash','pending',1,NULL,'2025-12-02 13:21:19','2025-12-02 13:21:19',NULL,NULL),(5,'ORD-20251202-E872D9','dine-in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',60.00,9.60,0.00,0.00,69.60,0.00,0.00,'cash','pending',1,NULL,'2025-12-02 13:21:50','2025-12-02 13:21:50',NULL,NULL),(6,'ORD-20251202-4657AE','dine-in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',3200.00,512.00,0.00,0.00,3712.00,0.00,0.00,'cash','pending',1,NULL,'2025-12-02 13:23:32','2025-12-02 13:23:32',NULL,NULL),(7,'ORD-20251202-1065A0','dine-in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',60.00,9.60,0.00,0.00,69.60,0.00,0.00,'cash','pending',1,NULL,'2025-12-02 13:27:13','2025-12-02 13:27:13',NULL,NULL),(8,'ORD-20251202-84DCD6','dine-in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',3200.00,512.00,0.00,0.00,3712.00,0.00,0.00,'cash','pending',1,NULL,'2025-12-02 13:32:08','2025-12-02 13:32:08',NULL,NULL),(9,'ORD-20251202-B51004','dine-in',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'preparing',3200.00,512.00,0.00,0.00,3712.00,0.00,3712.00,'cash','paid',1,NULL,'2025-12-02 13:49:15','2025-12-02 13:49:18',NULL,NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_installments`
--

DROP TABLE IF EXISTS `payment_installments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_installments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `due_date` date NOT NULL,
  `amount_due` decimal(15,2) NOT NULL,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','paid','overdue','cancelled') DEFAULT 'pending',
  `payment_method` enum('cash','card','mobile_money','bank_transfer','voucher') DEFAULT 'cash',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_payment_installments_order` (`order_id`),
  KEY `idx_payment_installments_status` (`status`),
  CONSTRAINT `payment_installments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_installments`
--

LOCK TABLES `payment_installments` WRITE;
/*!40000 ALTER TABLE `payment_installments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_installments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_actions`
--

DROP TABLE IF EXISTS `permission_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(10) unsigned NOT NULL,
  `action_key` varchar(50) NOT NULL,
  `action_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_module_action` (`module_id`,`action_key`),
  CONSTRAINT `permission_actions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `permission_modules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_actions`
--

LOCK TABLES `permission_actions` WRITE;
/*!40000 ALTER TABLE `permission_actions` DISABLE KEYS */;
INSERT INTO `permission_actions` VALUES (1,1,'view','View POS','View POS transactions and reports',1,'2025-12-01 08:57:08'),(2,1,'create','Create Sale','Create new POS transactions',1,'2025-12-01 08:57:08'),(3,1,'update','Update Sale','Modify existing POS transactions',1,'2025-12-01 08:57:08'),(4,1,'refund','Issue Refunds','Process POS refunds',1,'2025-12-01 08:57:08'),(5,1,'void','Void Sale','Void POS transactions',1,'2025-12-01 08:57:08'),(6,3,'view','View Inventory','View stock levels and movements',1,'2025-12-01 08:57:08'),(7,3,'create','Create Inventory Entry','Add new inventory records',1,'2025-12-01 08:57:08'),(8,3,'update','Update Inventory','Modify inventory records',1,'2025-12-01 08:57:08'),(9,3,'adjust_inventory','Adjust Inventory','Execute stock adjustments',1,'2025-12-01 08:57:08'),(10,21,'view','View Tasks','Access housekeeping dashboards and tasks',1,'2025-12-01 08:57:08'),(11,21,'create','Create Task','Create new housekeeping tasks',1,'2025-12-01 08:57:08'),(12,21,'update','Update Task','Update housekeeping tasks',1,'2025-12-01 08:57:08'),(13,21,'assign','Assign Task','Assign or reassign housekeeping tasks',1,'2025-12-01 08:57:08'),(14,21,'complete','Complete Task','Mark housekeeping tasks complete',1,'2025-12-01 08:57:08'),(15,22,'view','View Requests','Access maintenance requests',1,'2025-12-01 08:57:08'),(16,22,'create','Create Request','Log new maintenance issues',1,'2025-12-01 08:57:08'),(17,22,'update','Update Request','Update maintenance request details',1,'2025-12-01 08:57:08'),(18,22,'assign','Assign Request','Assign maintenance requests to staff',1,'2025-12-01 08:57:08'),(19,22,'resolve','Resolve Request','Mark maintenance requests resolved',1,'2025-12-01 08:57:08'),(20,23,'view','View Front Desk','Access front desk dashboards',1,'2025-12-01 08:57:08'),(21,23,'create','Create Record','Create guest or stay records',1,'2025-12-01 08:57:08'),(22,23,'update','Update Record','Update guest or stay records',1,'2025-12-01 08:57:08'),(23,6,'view','View Users','View user directory',1,'2025-12-01 08:57:08'),(24,6,'create','Create User','Create new user accounts',1,'2025-12-01 08:57:08'),(25,6,'update','Update User','Update existing user accounts',1,'2025-12-01 08:57:08'),(26,6,'change_permissions','Change Permissions','Adjust user/group permissions',1,'2025-12-01 08:57:08');
/*!40000 ALTER TABLE `permission_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_audit_log`
--

DROP TABLE IF EXISTS `permission_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `target_user_id` int(10) unsigned DEFAULT NULL,
  `action_type` enum('login_attempt','login_success','login_failure','logout','permission_check','permission_denied','permission_granted','permission_changed','sensitive_action','policy_violation') NOT NULL,
  `module_id` int(10) unsigned DEFAULT NULL,
  `action_id` int(10) unsigned DEFAULT NULL,
  `resource_type` varchar(100) DEFAULT NULL,
  `resource_id` int(10) unsigned DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `risk_level` enum('low','medium','high','critical') DEFAULT 'low',
  `additional_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_data`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_target_user_id` (`target_user_id`),
  KEY `idx_action_type` (`action_type`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_risk_level` (`risk_level`),
  KEY `module_id` (`module_id`),
  KEY `action_id` (`action_id`),
  KEY `idx_permission_audit_log_user_action` (`user_id`,`action_type`,`created_at`),
  CONSTRAINT `permission_audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `permission_audit_log_ibfk_2` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `permission_audit_log_ibfk_3` FOREIGN KEY (`module_id`) REFERENCES `system_modules` (`id`) ON DELETE SET NULL,
  CONSTRAINT `permission_audit_log_ibfk_4` FOREIGN KEY (`action_id`) REFERENCES `system_actions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_audit_log`
--

LOCK TABLES `permission_audit_log` WRITE;
/*!40000 ALTER TABLE `permission_audit_log` DISABLE KEYS */;
INSERT INTO `permission_audit_log` VALUES (1,1,NULL,'permission_granted',2,2,NULL,NULL,NULL,NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','j1nkp4fevpfnmm82opokkd3dir','low','{\"details\":\"Permission granted to user 19. Reason: \"}','2025-12-03 14:27:38');
/*!40000 ALTER TABLE `permission_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_groups`
--

DROP TABLE IF EXISTS `permission_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(7) DEFAULT '#007bff',
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_name` (`group_name`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `permission_groups_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_groups`
--

LOCK TABLES `permission_groups` WRITE;
/*!40000 ALTER TABLE `permission_groups` DISABLE KEYS */;
INSERT INTO `permission_groups` VALUES (1,'Super Administrators','Full system access with all permissions','#dc3545',1,NULL,'2025-12-03 13:59:02','2025-12-03 13:59:02'),(2,'Store Managers','Full operational access with reporting capabilities','#28a745',1,NULL,'2025-12-03 13:59:02','2025-12-03 13:59:02'),(3,'Shift Supervisors','Limited management access for shift operations','#ffc107',1,NULL,'2025-12-03 13:59:02','2025-12-03 13:59:02'),(4,'Cashiers','Basic POS operations and customer service','#17a2b8',1,NULL,'2025-12-03 13:59:02','2025-12-03 13:59:02'),(5,'Waiters','Restaurant service and order management','#6f42c1',1,NULL,'2025-12-03 13:59:02','2025-12-03 13:59:02'),(6,'Kitchen Staff','Kitchen operations and order fulfillment','#fd7e14',1,NULL,'2025-12-03 13:59:02','2025-12-03 13:59:02'),(7,'Delivery Personnel','Delivery operations and order tracking','#20c997',1,NULL,'2025-12-03 13:59:02','2025-12-03 13:59:02'),(8,'Inventory Managers','Product and inventory management','#6c757d',1,NULL,'2025-12-03 13:59:02','2025-12-03 13:59:02'),(9,'Accountants','Financial reporting and accounting access','#343a40',1,NULL,'2025-12-03 13:59:02','2025-12-03 13:59:02'),(10,'Maintenance Staff','Limited access for system maintenance','#e83e8c',1,NULL,'2025-12-03 13:59:02','2025-12-03 13:59:02');
/*!40000 ALTER TABLE `permission_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_modules`
--

DROP TABLE IF EXISTS `permission_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `display_name` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `module_key` varchar(100) NOT NULL,
  `module_name` varchar(150) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_key` (`module_key`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_modules`
--

LOCK TABLES `permission_modules` WRITE;
/*!40000 ALTER TABLE `permission_modules` DISABLE KEYS */;
INSERT INTO `permission_modules` VALUES (1,'Point of Sale','Point of Sale','POS transactions and sales','pos','Point of Sale',NULL,0,1,'2025-12-01 06:46:49','2025-12-01 08:52:04'),(2,'Restaurant','Restaurant','Table service and kitchen management','restaurant','Restaurant Operations',NULL,0,1,'2025-12-01 06:46:49','2025-12-01 08:52:04'),(3,'Inventory','Inventory','Stock control and purchasing','inventory','Inventory Management',NULL,0,1,'2025-12-01 06:46:49','2025-12-01 08:52:04'),(4,'Accounting','Accounting','Financial management and reporting','accounting','Accounting & Finance',NULL,0,1,'2025-12-01 06:46:49','2025-12-01 08:52:04'),(5,'Customers','Customers','Customer data and CRM','customers','Customer Management',NULL,0,1,'2025-12-01 06:46:49','2025-12-01 08:52:04'),(6,'Users','Users','User accounts and permissions','users','User Management',NULL,0,1,'2025-12-01 06:46:49','2025-12-01 08:52:04'),(7,'Reports','Reports','Business intelligence and reporting','reports','Reports & Analytics',NULL,0,1,'2025-12-01 06:46:49','2025-12-01 08:52:04'),(8,'Settings','Settings','System configuration and preferences','settings','System Settings',NULL,0,1,'2025-12-01 06:46:49','2025-12-01 08:52:04'),(9,'Rooms','Rooms','Hotel room bookings and management','rooms','Room Management',NULL,0,1,'2025-12-01 06:46:49','2025-12-01 08:52:04'),(10,'Delivery','Delivery','Order delivery and logistics','delivery','Delivery Management',NULL,0,1,'2025-12-01 06:46:49','2025-12-01 08:52:04'),(21,'',NULL,'Scheduling, room status, and task execution','housekeeping','Housekeeping',NULL,0,1,'2025-12-01 08:52:04','2025-12-01 08:52:04'),(22,'',NULL,'Issue tracking, technician dispatch, and resolution','maintenance','Maintenance',NULL,0,1,'2025-12-01 08:52:04','2025-12-01 08:52:04'),(23,'',NULL,'Guest services, check-ins, and concierge workflows','frontdesk','Front Desk',NULL,0,1,'2025-12-01 08:52:04','2025-12-01 08:52:04');
/*!40000 ALTER TABLE `permission_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_templates`
--

DROP TABLE IF EXISTS `permission_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `template_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`template_data`)),
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `permission_templates_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_templates`
--

LOCK TABLES `permission_templates` WRITE;
/*!40000 ALTER TABLE `permission_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_promotions`
--

DROP TABLE IF EXISTS `pos_promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_promotions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `promotion_type` enum('bundle_price','percent','fixed') NOT NULL DEFAULT 'bundle_price',
  `min_quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `bundle_price` decimal(15,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `applies_to` enum('product','category','order') DEFAULT 'product',
  `product_id` int(10) unsigned DEFAULT NULL,
  `applicable_modules` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`applicable_modules`)),
  `days_of_week` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`days_of_week`)),
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `discount_type` enum('percent','amount') DEFAULT 'percent',
  `discount_value` decimal(15,2) DEFAULT NULL,
  `min_order_amount` decimal(15,2) DEFAULT 0.00,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `usage_limit` int(11) DEFAULT 0,
  `usage_count` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(10) unsigned DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 100,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `category_id` (`category_id`),
  KEY `idx_active` (`is_active`),
  KEY `idx_dates` (`start_date`,`end_date`),
  CONSTRAINT `pos_promotions_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pos_promotions_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_promotions`
--

LOCK TABLES `pos_promotions` WRITE;
/*!40000 ALTER TABLE `pos_promotions` DISABLE KEYS */;
INSERT INTO `pos_promotions` VALUES (1,'Black Friday','percent',1,0.00,'black friday','product',1,NULL,NULL,'14:38:00','14:39:00',NULL,'percent',5.00,0.00,'2025-12-03','2025-12-31',0,0,1,1,100,'2025-12-02 11:39:08','2025-12-02 11:39:08'),(2,'bucket Night','bundle_price',5,20000.00,NULL,'product',1,'[\"restaurant\"]','[5]',NULL,NULL,NULL,'percent',0.00,0.00,NULL,NULL,0,0,1,1,100,'2025-12-02 11:51:30','2025-12-02 11:52:06'),(3,'Black Friday','percent',1,0.00,'free bottle','product',1,'[\"restaurant\",\"rooms\"]',NULL,'20:59:00',NULL,NULL,'percent',10.00,0.00,'2025-12-03','2025-12-31',0,0,1,1,100,'2025-12-02 11:53:11','2025-12-02 11:53:11');
/*!40000 ALTER TABLE `pos_promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_register_closures`
--

DROP TABLE IF EXISTS `pos_register_closures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_register_closures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `closure_type` enum('X','Y','Z') NOT NULL,
  `session_id` int(10) unsigned DEFAULT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `range_start` datetime NOT NULL,
  `range_end` datetime NOT NULL,
  `totals_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`totals_json`)),
  `generated_by_user_id` int(10) unsigned NOT NULL,
  `generated_at` datetime NOT NULL,
  `reset_applied` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_closure_type` (`closure_type`),
  KEY `idx_closure_generated` (`generated_at`),
  KEY `fk_closure_session` (`session_id`),
  CONSTRAINT `fk_closure_session` FOREIGN KEY (`session_id`) REFERENCES `pos_register_sessions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_register_closures`
--

LOCK TABLES `pos_register_closures` WRITE;
/*!40000 ALTER TABLE `pos_register_closures` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_register_closures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_register_sessions`
--

DROP TABLE IF EXISTS `pos_register_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_register_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `register_id` int(10) unsigned NOT NULL,
  `opened_by` int(10) unsigned NOT NULL,
  `closed_by` int(10) unsigned DEFAULT NULL,
  `opening_time` datetime NOT NULL,
  `closing_time` datetime DEFAULT NULL,
  `opened_at` datetime DEFAULT NULL,
  `opening_amount` decimal(15,2) NOT NULL,
  `closing_amount` decimal(15,2) DEFAULT NULL,
  `expected_amount` decimal(15,2) DEFAULT NULL,
  `cash_sales` decimal(15,2) DEFAULT 0.00,
  `card_sales` decimal(15,2) DEFAULT 0.00,
  `mobile_money_sales` decimal(15,2) DEFAULT 0.00,
  `discrepancy` decimal(15,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `status` enum('open','closed') DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `register_id` (`register_id`),
  KEY `opened_by` (`opened_by`),
  KEY `closed_by` (`closed_by`),
  CONSTRAINT `pos_register_sessions_ibfk_1` FOREIGN KEY (`register_id`) REFERENCES `pos_registers` (`id`),
  CONSTRAINT `pos_register_sessions_ibfk_2` FOREIGN KEY (`opened_by`) REFERENCES `users` (`id`),
  CONSTRAINT `pos_register_sessions_ibfk_3` FOREIGN KEY (`closed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_register_sessions`
--

LOCK TABLES `pos_register_sessions` WRITE;
/*!40000 ALTER TABLE `pos_register_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_register_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_registers`
--

DROP TABLE IF EXISTS `pos_registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_registers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) DEFAULT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `cash_drawer_status` enum('closed','open','locked') DEFAULT 'closed',
  `starting_cash` decimal(15,2) DEFAULT 0.00,
  `allow_overage` smallint(6) DEFAULT 0,
  `allow_shortage` smallint(6) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `pos_registers_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_registers`
--

LOCK TABLES `pos_registers` WRITE;
/*!40000 ALTER TABLE `pos_registers` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_registers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_log`
--

DROP TABLE IF EXISTS `print_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `print_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `document_type` varchar(50) NOT NULL,
  `document_id` int(10) unsigned DEFAULT NULL,
  `printer_name` varchar(150) DEFAULT NULL,
  `print_status` enum('pending','printed','failed') DEFAULT 'printed',
  `error_message` text DEFAULT NULL,
  `printed_by` int(10) unsigned DEFAULT NULL,
  `printed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `printed_by` (`printed_by`),
  KEY `idx_print_log_doc` (`document_type`,`document_id`),
  KEY `idx_print_log_status` (`print_status`),
  CONSTRAINT `print_log_ibfk_1` FOREIGN KEY (`printed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_log`
--

LOCK TABLES `print_log` WRITE;
/*!40000 ALTER TABLE `print_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `print_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_batches`
--

DROP TABLE IF EXISTS `product_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_batches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `batch_number` varchar(100) NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `received_quantity` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `remaining_quantity` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `cost_price` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `status` enum('available','reserved','used','expired','disposed') DEFAULT 'available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_product_batch` (`product_id`,`batch_number`),
  KEY `idx_product_batches_status` (`status`),
  KEY `idx_batch_expiry` (`expiry_date`),
  CONSTRAINT `product_batches_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_batches`
--

LOCK TABLES `product_batches` WRITE;
/*!40000 ALTER TABLE `product_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_portions`
--

DROP TABLE IF EXISTS `product_portions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_portions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `portion_name` varchar(100) NOT NULL,
  `portion_size_ml` decimal(10,2) DEFAULT NULL COMMENT 'Size in ml for liquids',
  `portion_quantity` decimal(10,4) NOT NULL DEFAULT 1.0000 COMMENT 'How much of base unit this portion uses',
  `selling_price` decimal(15,2) NOT NULL,
  `cost_price` decimal(15,2) DEFAULT 0.00,
  `is_default` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_product_portion` (`product_id`,`portion_name`),
  KEY `idx_product` (`product_id`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_portions`
--

LOCK TABLES `product_portions` WRITE;
/*!40000 ALTER TABLE `product_portions` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_portions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_recipes`
--

DROP TABLE IF EXISTS `product_recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_recipes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `ingredient_product_id` int(10) unsigned NOT NULL,
  `quantity` decimal(18,4) NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recipe_product` (`product_id`),
  KEY `idx_recipe_ingredient` (`ingredient_product_id`),
  CONSTRAINT `fk_recipe_ingredient` FOREIGN KEY (`ingredient_product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `fk_recipe_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_recipes`
--

LOCK TABLES `product_recipes` WRITE;
/*!40000 ALTER TABLE `product_recipes` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_recipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_yields`
--

DROP TABLE IF EXISTS `product_yields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_yields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `purchase_unit` varchar(50) NOT NULL COMMENT 'e.g., bottle, crate, case',
  `purchase_size_ml` int(11) DEFAULT NULL COMMENT 'Size in ml for liquids',
  `expected_portions` int(11) NOT NULL COMMENT 'Expected number of portions per unit',
  `portion_size_ml` decimal(10,2) DEFAULT NULL COMMENT 'Standard portion size',
  `wastage_allowance_percent` decimal(5,2) DEFAULT 2.00 COMMENT 'Acceptable wastage %',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_product_yield` (`product_id`),
  KEY `idx_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_yields`
--

LOCK TABLES `product_yields` WRITE;
/*!40000 ALTER TABLE `product_yields` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_yields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT NULL,
  `module_scope` enum('retail','restaurant','housekeeping','maintenance','general') DEFAULT 'retail',
  `is_consumable` tinyint(1) NOT NULL DEFAULT 0,
  `supplier_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `barcode` varchar(50) DEFAULT NULL,
  `cost_price` decimal(15,2) DEFAULT 0.00,
  `selling_price` decimal(15,2) NOT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `min_stock_level` int(11) DEFAULT 10,
  `reorder_level` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `reorder_quantity` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `unit` varchar(20) DEFAULT 'pcs',
  `track_expiry` tinyint(1) NOT NULL DEFAULT 0,
  `track_wastage` tinyint(1) NOT NULL DEFAULT 0,
  `tax_rate` decimal(5,2) DEFAULT 0.00,
  `is_active` tinyint(1) DEFAULT 1,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_portioned` tinyint(1) DEFAULT 0 COMMENT 'Sold in portions (tots/shots/glasses)',
  `bottle_size_ml` int(11) DEFAULT NULL COMMENT 'Size in ml for liquor bottles',
  `default_portion_ml` decimal(10,2) DEFAULT NULL COMMENT 'Default pour size in ml',
  `is_recipe` tinyint(1) DEFAULT 0 COMMENT 'Is a cocktail/recipe',
  `recipe_id` int(10) unsigned DEFAULT NULL COMMENT 'Link to bar_recipes',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`),
  UNIQUE KEY `barcode` (`barcode`),
  KEY `idx_name` (`name`),
  KEY `idx_sku` (`sku`),
  KEY `idx_barcode` (`barcode`),
  KEY `idx_category` (`category_id`),
  KEY `idx_products_supplier` (`supplier_id`),
  KEY `idx_products_category` (`category_id`),
  KEY `idx_products_active` (`is_active`),
  KEY `idx_products_deleted` (`deleted_at`),
  CONSTRAINT `fk_products_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,3,'retail',0,NULL,'Bottled Water 500ml',NULL,NULL,'BW-500',NULL,20.00,60.00,88,10,0.0000,0.0000,'pcs',0,0,0.00,1,NULL,'2025-11-27 13:48:24','2025-12-03 08:07:20',NULL,0,NULL,NULL,0,NULL),(2,4,'retail',0,NULL,'Room Linen Set',NULL,NULL,'RL-SET',NULL,1500.00,3200.00,14,10,0.0000,0.0000,'pcs',0,0,0.00,1,NULL,'2025-11-27 13:48:24','2025-12-03 08:09:27',NULL,0,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `ordered_quantity` decimal(12,2) NOT NULL,
  `received_quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `unit_cost` decimal(15,4) NOT NULL,
  `tax_amount` decimal(15,4) DEFAULT 0.0000,
  `discount_amount` decimal(15,4) DEFAULT 0.0000,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_po_items_po` (`purchase_order_id`),
  KEY `idx_po_items_product` (`product_id`),
  CONSTRAINT `purchase_order_items_ibfk_1` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `po_number` varchar(50) NOT NULL,
  `supplier_id` int(10) unsigned NOT NULL,
  `status` enum('pending','approved','ordered','received','cancelled') DEFAULT 'pending',
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_number` (`po_number`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `purchase_orders_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `register_cash_movements`
--

DROP TABLE IF EXISTS `register_cash_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `register_cash_movements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` int(10) unsigned NOT NULL,
  `movement_type` enum('cash_in','cash_out','float','pickup','drop') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `authorized_by` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `authorized_by` (`authorized_by`),
  KEY `created_by` (`created_by`),
  KEY `idx_session` (`session_id`),
  KEY `idx_type` (`movement_type`),
  CONSTRAINT `register_cash_movements_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `register_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `register_cash_movements_ibfk_2` FOREIGN KEY (`authorized_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `register_cash_movements_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `register_cash_movements`
--

LOCK TABLES `register_cash_movements` WRITE;
/*!40000 ALTER TABLE `register_cash_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `register_cash_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `register_sessions`
--

DROP TABLE IF EXISTS `register_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `register_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `register_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `session_number` varchar(50) NOT NULL,
  `opening_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `closing_balance` decimal(15,2) DEFAULT NULL,
  `expected_balance` decimal(15,2) DEFAULT NULL,
  `variance` decimal(15,2) DEFAULT NULL,
  `cash_sales` decimal(15,2) DEFAULT 0.00,
  `card_sales` decimal(15,2) DEFAULT 0.00,
  `mobile_sales` decimal(15,2) DEFAULT 0.00,
  `total_sales` decimal(15,2) DEFAULT 0.00,
  `total_refunds` decimal(15,2) DEFAULT 0.00,
  `total_voids` decimal(15,2) DEFAULT 0.00,
  `cash_in` decimal(15,2) DEFAULT 0.00,
  `cash_out` decimal(15,2) DEFAULT 0.00,
  `transaction_count` int(11) DEFAULT 0,
  `opened_at` datetime NOT NULL,
  `closed_at` datetime DEFAULT NULL,
  `status` enum('open','closed','suspended') DEFAULT 'open',
  `closing_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_session_number` (`session_number`),
  KEY `idx_register` (`register_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_opened_at` (`opened_at`),
  CONSTRAINT `register_sessions_ibfk_1` FOREIGN KEY (`register_id`) REFERENCES `registers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `register_sessions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `register_sessions`
--

LOCK TABLES `register_sessions` WRITE;
/*!40000 ALTER TABLE `register_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `register_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registers`
--

DROP TABLE IF EXISTS `registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `location_id` int(10) unsigned NOT NULL,
  `register_number` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `register_type` enum('pos','bar','restaurant','retail','service') DEFAULT 'pos',
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `mac_address` varchar(17) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `opening_balance` decimal(15,2) DEFAULT 0.00,
  `current_balance` decimal(15,2) DEFAULT 0.00,
  `last_opened_at` datetime DEFAULT NULL,
  `last_closed_at` datetime DEFAULT NULL,
  `last_opened_by` int(10) unsigned DEFAULT NULL,
  `last_closed_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_location_register` (`location_id`,`register_number`),
  KEY `last_opened_by` (`last_opened_by`),
  KEY `last_closed_by` (`last_closed_by`),
  KEY `idx_location` (`location_id`),
  KEY `idx_type` (`register_type`),
  KEY `idx_active` (`is_active`),
  CONSTRAINT `registers_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `registers_ibfk_2` FOREIGN KEY (`last_opened_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `registers_ibfk_3` FOREIGN KEY (`last_closed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registers`
--

LOCK TABLES `registers` WRITE;
/*!40000 ALTER TABLE `registers` DISABLE KEYS */;
INSERT INTO `registers` VALUES (1,13,'REG-01','Flagship Hotel - Main Register','pos',NULL,NULL,NULL,1,0.00,0.00,NULL,NULL,NULL,NULL,'2025-12-05 10:52:05','2025-12-05 10:52:05'),(2,14,'REG-01','Downtown Bistro - Main Register','pos',NULL,NULL,NULL,1,0.00,0.00,NULL,NULL,NULL,NULL,'2025-12-05 10:52:05','2025-12-05 10:52:05');
/*!40000 ALTER TABLE `registers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reorder_alerts`
--

DROP TABLE IF EXISTS `reorder_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reorder_alerts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_item_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `alert_type` enum('stock_out','reorder_point','buffer','expiry') DEFAULT 'reorder_point',
  `alert_level` enum('info','warning','critical') DEFAULT 'warning',
  `current_stock` decimal(18,4) NOT NULL,
  `reorder_level` decimal(18,4) NOT NULL,
  `recommended_order_quantity` decimal(18,4) NOT NULL DEFAULT 0.0000,
  `status` enum('pending','ordered','resolved','ignored') NOT NULL DEFAULT 'pending',
  `acknowledged_by` int(10) unsigned DEFAULT NULL,
  `acknowledged_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `acknowledged_by` (`acknowledged_by`),
  KEY `idx_reorder_alerts_item` (`inventory_item_id`),
  KEY `idx_reorder_alerts_level` (`alert_level`),
  KEY `idx_reorder_status` (`status`),
  CONSTRAINT `reorder_alerts_ibfk_1` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reorder_alerts_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reorder_alerts_ibfk_3` FOREIGN KEY (`acknowledged_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reorder_alerts`
--

LOCK TABLES `reorder_alerts` WRITE;
/*!40000 ALTER TABLE `reorder_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `reorder_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation_deposit_payments`
--

DROP TABLE IF EXISTS `reservation_deposit_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation_deposit_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` int(10) unsigned NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `payment_method` enum('cash','card','mobile_money','bank_transfer','voucher') NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `received_by` int(10) unsigned DEFAULT NULL,
  `received_at` datetime NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `received_by` (`received_by`),
  KEY `idx_reservation_deposits_reservation` (`reservation_id`),
  CONSTRAINT `reservation_deposit_payments_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `table_reservations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reservation_deposit_payments_ibfk_2` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation_deposit_payments`
--

LOCK TABLES `reservation_deposit_payments` WRITE;
/*!40000 ALTER TABLE `reservation_deposit_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation_deposit_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant_tables`
--

DROP TABLE IF EXISTS `restaurant_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurant_tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_number` varchar(20) NOT NULL,
  `table_name` varchar(100) DEFAULT NULL,
  `capacity` int(11) DEFAULT 4,
  `floor` varchar(50) DEFAULT NULL,
  `status` enum('available','occupied','reserved','maintenance') DEFAULT 'available',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_table_number` (`table_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant_tables`
--

LOCK TABLES `restaurant_tables` WRITE;
/*!40000 ALTER TABLE `restaurant_tables` DISABLE KEYS */;
INSERT INTO `restaurant_tables` VALUES (1,'T1','Table 1',4,'Ground Floor','available',1,'2025-12-03 08:58:03');
/*!40000 ALTER TABLE `restaurant_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rider_location_history`
--

DROP TABLE IF EXISTS `rider_location_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rider_location_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rider_id` int(10) unsigned NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `accuracy_meters` decimal(8,2) DEFAULT NULL,
  `speed_kmh` decimal(8,2) DEFAULT NULL,
  `heading_deg` decimal(8,2) DEFAULT NULL,
  `battery_level` tinyint(3) unsigned DEFAULT NULL,
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_rlh_rider` (`rider_id`),
  KEY `idx_rlh_time` (`recorded_at`),
  CONSTRAINT `rider_location_history_ibfk_1` FOREIGN KEY (`rider_id`) REFERENCES `riders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rider_location_history`
--

LOCK TABLES `rider_location_history` WRITE;
/*!40000 ALTER TABLE `rider_location_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `rider_location_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `riders`
--

DROP TABLE IF EXISTS `riders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `riders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `license_number` varchar(50) DEFAULT NULL,
  `vehicle_type` enum('motorcycle','bicycle','car','van','other') DEFAULT 'motorcycle',
  `vehicle_number` varchar(50) DEFAULT NULL,
  `vehicle_make` varchar(100) DEFAULT NULL,
  `vehicle_color` varchar(50) DEFAULT NULL,
  `emergency_contact` varchar(100) DEFAULT NULL,
  `vehicle_plate_photo_url` varchar(255) DEFAULT NULL,
  `vehicle_plate` varchar(20) DEFAULT NULL,
  `status` enum('available','busy','inactive') DEFAULT 'available',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `assigned_deliveries` int(11) DEFAULT 0,
  `total_deliveries` int(11) DEFAULT 0,
  `rating` decimal(3,2) DEFAULT 5.00,
  `last_assigned_at` datetime DEFAULT NULL,
  `is_online` tinyint(1) DEFAULT 0,
  `current_latitude` decimal(10,8) DEFAULT NULL,
  `current_longitude` decimal(11,8) DEFAULT NULL,
  `location_accuracy` float DEFAULT NULL,
  `battery_level` tinyint(3) unsigned DEFAULT NULL,
  `speed_kmh` float DEFAULT NULL,
  `heading_deg` float DEFAULT NULL,
  `insurance_expiry` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `riders`
--

LOCK TABLES `riders` WRITE;
/*!40000 ALTER TABLE `riders` DISABLE KEYS */;
/*!40000 ALTER TABLE `riders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_booking_migrations`
--

DROP TABLE IF EXISTS `room_booking_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_booking_migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `executed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_room_booking_migration` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_booking_migrations`
--

LOCK TABLES `room_booking_migrations` WRITE;
/*!40000 ALTER TABLE `room_booking_migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `room_booking_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_booking_payments`
--

DROP TABLE IF EXISTS `room_booking_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_booking_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_booking_id` int(10) unsigned NOT NULL,
  `payment_method` enum('cash','card','mobile_money','bank_transfer','voucher') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `received_by` int(10) unsigned DEFAULT NULL,
  `received_at` datetime NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `received_by` (`received_by`),
  KEY `idx_room_booking_payments_booking` (`room_booking_id`),
  CONSTRAINT `room_booking_payments_ibfk_1` FOREIGN KEY (`room_booking_id`) REFERENCES `room_bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `room_booking_payments_ibfk_2` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_booking_payments`
--

LOCK TABLES `room_booking_payments` WRITE;
/*!40000 ALTER TABLE `room_booking_payments` DISABLE KEYS */;
INSERT INTO `room_booking_payments` VALUES (3,18,'cash',150000.00,NULL,9,'2025-12-05 00:00:00',NULL,'2025-12-04 13:21:38','2025-12-04 13:21:38');
/*!40000 ALTER TABLE `room_booking_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_bookings`
--

DROP TABLE IF EXISTS `room_bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `booking_number` varchar(50) NOT NULL,
  `status` enum('pending','confirmed','checked_in','checked_out','cancelled') NOT NULL DEFAULT 'pending',
  `check_in_date` date NOT NULL,
  `check_out_date` date NOT NULL,
  `guests` int(11) NOT NULL DEFAULT 1,
  `nightly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `deposit_amount` decimal(12,2) DEFAULT 0.00,
  `balance_due` decimal(12,2) DEFAULT 0.00,
  `payment_status` enum('unpaid','partial','paid','refunded') NOT NULL DEFAULT 'unpaid',
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `legacy_booking_id` int(11) DEFAULT NULL,
  `total_nights` int(11) NOT NULL DEFAULT 1,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `guest_name` varchar(100) NOT NULL DEFAULT '',
  `guest_phone` varchar(20) NOT NULL DEFAULT '',
  `guest_email` varchar(100) DEFAULT NULL,
  `guest_id_number` varchar(50) DEFAULT NULL,
  `rate_per_night` decimal(10,2) NOT NULL DEFAULT 0.00,
  `adults` int(11) DEFAULT 1,
  `children` int(11) DEFAULT 0,
  `actual_check_in` datetime DEFAULT NULL,
  `actual_check_out` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_check_in` (`check_in_date`),
  KEY `fk_room_bookings_room` (`room_id`),
  KEY `fk_room_bookings_customer` (`customer_id`),
  KEY `fk_room_bookings_creator` (`created_by`),
  KEY `idx_bookings_status` (`status`),
  KEY `idx_bookings_checkin` (`check_in_date`),
  KEY `idx_bookings_checkout` (`check_out_date`),
  KEY `idx_bookings_deleted` (`deleted_at`),
  CONSTRAINT `fk_room_bookings_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_room_bookings_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_room_bookings_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_bookings`
--

LOCK TABLES `room_bookings` WRITE;
/*!40000 ALTER TABLE `room_bookings` DISABLE KEYS */;
INSERT INTO `room_bookings` VALUES (18,2,NULL,'BK-20251204-674111','checked_in','2025-12-05','2025-12-06',1,0.00,30000.00,0.00,0.00,'paid','test',9,'2025-12-04 13:21:38','2025-12-04 13:22:11',NULL,1,150000.00,NULL,'Mary','0780123456','mary@user.com','08937561551',30000.00,1,2,'2025-12-04 16:22:11',NULL);
/*!40000 ALTER TABLE `room_bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_folios`
--

DROP TABLE IF EXISTS `room_folios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_folios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `item_type` enum('room_charge','service','tax','deposit','payment','adjustment') NOT NULL,
  `description` varchar(200) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `quantity` decimal(10,2) DEFAULT 1.00,
  `reference_id` int(11) DEFAULT NULL,
  `reference_source` varchar(60) DEFAULT NULL,
  `date_charged` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_folios`
--

LOCK TABLES `room_folios` WRITE;
/*!40000 ALTER TABLE `room_folios` DISABLE KEYS */;
INSERT INTO `room_folios` VALUES (11,18,'room_charge','Room charge',30000.00,1.00,NULL,NULL,'2025-12-05','2025-12-04 13:21:38',9),(12,18,'payment','Deposit payment (CASH)',-150000.00,1.00,NULL,NULL,'2025-12-05','2025-12-04 13:21:38',9);
/*!40000 ALTER TABLE `room_folios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_types`
--

DROP TABLE IF EXISTS `room_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `base_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `capacity` int(11) NOT NULL DEFAULT 1,
  `amenities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`amenities`)),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_types`
--

LOCK TABLES `room_types` WRITE;
/*!40000 ALTER TABLE `room_types` DISABLE KEYS */;
INSERT INTO `room_types` VALUES (1,'Standard','standard',50000.00,2,NULL,1,'2025-12-04 12:02:06','2025-12-04 12:02:06'),(2,'Standard','single room',30000.00,1,NULL,1,'2025-12-04 12:02:42','2025-12-04 12:02:42');
/*!40000 ALTER TABLE `room_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_number` varchar(20) NOT NULL,
  `room_type_id` int(10) unsigned NOT NULL,
  `floor` varchar(50) DEFAULT NULL,
  `status` enum('available','occupied','maintenance','out_of_service') DEFAULT 'available',
  `housekeeping_status` enum('clean','dirty','inspected') DEFAULT 'clean',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `room_number` (`room_number`),
  KEY `room_type_id` (`room_type_id`),
  KEY `idx_rooms_status` (`status`),
  CONSTRAINT `rooms_ibfk_1` FOREIGN KEY (`room_type_id`) REFERENCES `room_types` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES (1,'102',1,'Ground Floor','available','clean',1,'2025-12-04 12:02:17','2025-12-04 12:02:17'),(2,'101',2,'Ground Floor','occupied','clean',1,'2025-12-04 12:02:58','2025-12-04 13:21:38');
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route_waypoints`
--

DROP TABLE IF EXISTS `route_waypoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `route_waypoints` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `delivery_route_id` int(10) unsigned NOT NULL,
  `sequence` int(10) unsigned NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `eta` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_route_waypoints_route` (`delivery_route_id`),
  KEY `idx_route_waypoints_sequence` (`sequence`),
  CONSTRAINT `route_waypoints_ibfk_1` FOREIGN KEY (`delivery_route_id`) REFERENCES `delivery_routes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route_waypoints`
--

LOCK TABLES `route_waypoints` WRITE;
/*!40000 ALTER TABLE `route_waypoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `route_waypoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_items`
--

DROP TABLE IF EXISTS `sale_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `tax_rate` decimal(5,2) DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `total_price` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sale` (`sale_id`),
  KEY `idx_product` (`product_id`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_items`
--

LOCK TABLES `sale_items` WRITE;
/*!40000 ALTER TABLE `sale_items` DISABLE KEYS */;
INSERT INTO `sale_items` VALUES (1,2,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(2,3,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(3,4,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(4,5,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(5,6,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(6,7,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(7,8,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(8,9,1,'Bottled Water 500ml',6,60.00,0.00,0.00,360.00),(9,10,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(10,11,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(11,12,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(12,13,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(13,14,2,'Room Linen Set',3,3200.00,0.00,0.00,9600.00),(14,15,1,'Bottled Water 500ml',3,60.00,0.00,0.00,180.00),(15,16,2,'Room Linen Set',3,3200.00,0.00,0.00,9600.00);
/*!40000 ALTER TABLE `sale_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_loyalty_summary`
--

DROP TABLE IF EXISTS `sale_loyalty_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_loyalty_summary` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `points_earned` int(11) NOT NULL DEFAULT 0,
  `points_redeemed` int(11) NOT NULL DEFAULT 0,
  `points_balance` int(11) NOT NULL DEFAULT 0,
  `program_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sls_sale` (`sale_id`),
  KEY `idx_sls_customer` (`customer_id`),
  KEY `program_id` (`program_id`),
  CONSTRAINT `sale_loyalty_summary_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_loyalty_summary_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sale_loyalty_summary_ibfk_3` FOREIGN KEY (`program_id`) REFERENCES `loyalty_programs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_loyalty_summary`
--

LOCK TABLES `sale_loyalty_summary` WRITE;
/*!40000 ALTER TABLE `sale_loyalty_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_loyalty_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_promotions`
--

DROP TABLE IF EXISTS `sale_promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_promotions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) unsigned NOT NULL,
  `promotion_id` int(10) unsigned DEFAULT NULL,
  `promotion_name` varchar(150) DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `product_name` varchar(150) DEFAULT NULL,
  `discount_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `details` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sale_promotions_sale` (`sale_id`),
  KEY `idx_sale_promotions_promo` (`promotion_id`),
  CONSTRAINT `fk_sale_promotions_sale` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_promotions`
--

LOCK TABLES `sale_promotions` WRITE;
/*!40000 ALTER TABLE `sale_promotions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sale_promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `external_id` varchar(100) DEFAULT NULL,
  `device_id` varchar(100) DEFAULT NULL,
  `sale_number` varchar(50) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `register_id` int(10) unsigned DEFAULT NULL,
  `session_id` int(10) unsigned DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `mobile_money_phone` varchar(30) DEFAULT NULL,
  `mobile_money_reference` varchar(100) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `tax_amount` decimal(15,2) DEFAULT 0.00,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL,
  `amount_paid` decimal(15,2) NOT NULL,
  `change_amount` decimal(15,2) DEFAULT 0.00,
  `payment_method` enum('cash','card','mobile_money','bank_transfer','room_charge') DEFAULT 'cash',
  `room_booking_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sale_number` (`sale_number`),
  UNIQUE KEY `ux_sales_external_id` (`external_id`),
  KEY `idx_sale_number` (`sale_number`),
  KEY `idx_user` (`user_id`),
  KEY `idx_date` (`created_at`),
  KEY `idx_sales_location` (`location_id`),
  KEY `idx_sales_room_booking` (`room_booking_id`),
  KEY `idx_sales_mobile_reference` (`mobile_money_reference`),
  KEY `idx_sales_created_at` (`created_at`),
  KEY `idx_sales_payment_method` (`payment_method`),
  KEY `idx_sales_customer_phone` (`customer_phone`),
  KEY `idx_sales_deleted` (`deleted_at`),
  KEY `idx_register` (`register_id`),
  KEY `idx_session` (`session_id`),
  CONSTRAINT `fk_sales_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (2,NULL,NULL,'SAL-20251203-0001',1,13,NULL,NULL,NULL,NULL,NULL,NULL,180.00,28.80,0.00,208.80,500.00,291.20,'cash',NULL,NULL,'2025-12-03 07:11:56',NULL),(3,NULL,NULL,'SAL-20251203-0002',1,13,NULL,NULL,NULL,NULL,NULL,NULL,180.00,28.80,0.00,208.80,500.00,291.20,'cash',NULL,NULL,'2025-12-03 07:13:30',NULL),(4,NULL,NULL,'SAL-20251203-0003',1,13,NULL,NULL,NULL,NULL,NULL,NULL,180.00,28.80,0.00,208.80,500.00,291.20,'cash',NULL,NULL,'2025-12-03 07:17:22',NULL),(5,NULL,NULL,'SAL-20251203-0004',1,13,NULL,NULL,NULL,NULL,NULL,NULL,180.00,28.80,0.00,208.80,500.00,291.20,'cash',NULL,NULL,'2025-12-03 07:17:44',NULL),(6,NULL,NULL,'SAL-20251203-0005',1,13,NULL,NULL,NULL,NULL,NULL,NULL,180.00,28.80,0.00,208.80,500.00,291.20,'cash',NULL,NULL,'2025-12-03 07:19:37',NULL),(7,NULL,NULL,'SAL-20251203-0006',1,13,NULL,NULL,NULL,NULL,NULL,NULL,180.00,28.80,0.00,208.80,500.00,291.20,'cash',NULL,NULL,'2025-12-03 07:21:17',NULL),(8,NULL,NULL,'SAL-20251203-0007',1,13,NULL,NULL,NULL,NULL,NULL,NULL,180.00,28.80,0.00,208.80,500.00,291.20,'cash',NULL,NULL,'2025-12-03 07:23:33',NULL),(9,NULL,NULL,'SAL-20251203-0008',1,13,NULL,NULL,NULL,NULL,NULL,NULL,360.00,57.60,0.00,417.60,1000.00,582.40,'cash',NULL,NULL,'2025-12-03 07:24:12',NULL),(10,NULL,NULL,'SAL-20251203-0009',1,13,NULL,NULL,NULL,NULL,NULL,NULL,180.00,28.80,0.00,208.80,500.00,291.20,'cash',NULL,NULL,'2025-12-03 07:25:54',NULL),(11,NULL,NULL,'SAL-20251203-0010',1,13,NULL,NULL,NULL,NULL,NULL,NULL,180.00,28.80,0.00,208.80,500.00,291.20,'cash',NULL,NULL,'2025-12-03 07:27:49',NULL),(12,NULL,NULL,'SAL-20251203-0011',1,13,NULL,NULL,NULL,NULL,NULL,NULL,180.00,28.80,0.00,208.80,208.80,0.00,'mobile_money',NULL,NULL,'2025-12-03 07:28:31',NULL),(13,NULL,NULL,'SAL-20251203-0012',1,13,NULL,NULL,NULL,NULL,'+256784237617',NULL,180.00,28.80,0.00,208.80,208.80,0.00,'mobile_money',NULL,NULL,'2025-12-03 07:52:44',NULL),(14,NULL,NULL,'SAL-20251203-0013',1,13,NULL,NULL,NULL,NULL,NULL,NULL,9600.00,1536.00,0.00,11136.00,11136.00,0.00,'card',NULL,NULL,'2025-12-03 07:55:32',NULL),(15,NULL,NULL,'SAL-20251203-0014',1,13,NULL,NULL,NULL,NULL,'+256784237617','eeeeee',180.00,28.80,0.00,208.80,208.80,0.00,'mobile_money',NULL,NULL,'2025-12-03 08:07:20',NULL),(16,NULL,NULL,'SAL-20251203-0015',1,13,NULL,NULL,NULL,NULL,'+256784237617',NULL,9600.00,1536.00,0.00,11136.00,11136.00,0.00,'mobile_money',NULL,NULL,'2025-12-03 08:09:27',NULL);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_tasks`
--

DROP TABLE IF EXISTS `scheduled_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scheduled_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_key` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `schedule_expression` varchar(50) NOT NULL,
  `last_run_at` datetime DEFAULT NULL,
  `next_run_at` datetime DEFAULT NULL,
  `status` enum('pending','running','success','failed') DEFAULT 'pending',
  `last_error` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_task_key` (`task_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_tasks`
--

LOCK TABLES `scheduled_tasks` WRITE;
/*!40000 ALTER TABLE `scheduled_tasks` DISABLE KEYS */;
INSERT INTO `scheduled_tasks` VALUES (1,'system_backup','Automated system backup (daily)','daily@02:00','2025-12-11 07:14:14','2025-12-10 02:00:00','running',NULL,1,'2025-12-09 10:29:15','2025-12-11 04:14:14');
/*!40000 ALTER TABLE `scheduled_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(50) NOT NULL DEFAULT 'string',
  `description` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'currency_code','','string',NULL,'2025-12-01 11:54:06'),(2,'currency_symbol','','string',NULL,'2025-12-01 11:54:06'),(3,'currency_name','Default Currency','string',NULL,'2025-12-01 11:54:06'),(4,'currency_position','before','string',NULL,'2025-11-26 13:54:15'),(5,'decimal_places','2','string',NULL,'2025-11-26 13:54:15'),(6,'decimal_separator','.','string',NULL,'2025-11-26 13:54:15'),(7,'thousands_separator',',','string',NULL,'2025-11-26 13:54:15'),(8,'currency_format','{symbol}{amount}','string',NULL,'2025-11-26 13:54:15'),(48,'company_name','Waesta International Hospitality','string','Primary brand name displayed across the platform','2025-11-27 13:48:24'),(49,'company_phone','+254700000000','string','Main support line','2025-11-27 13:48:24'),(50,'company_email','support@waesta.com','string','Official support email','2025-11-27 13:48:24'),(51,'default_currency','KES','string','Default currency code','2025-11-27 13:48:24'),(52,'timezone','Africa/Nairobi','string','Server/application timezone','2025-11-27 13:48:24'),(62,'business_name','Waesta','string',NULL,'2025-12-09 10:17:10'),(63,'business_address','','string',NULL,'2025-12-09 10:17:10'),(64,'business_phone','','string',NULL,'2025-12-09 10:17:10'),(65,'business_email','','string',NULL,'2025-12-09 10:17:10'),(66,'business_website','','string',NULL,'2025-12-09 10:17:10'),(67,'tax_rate','16','string',NULL,'2025-12-09 10:17:10'),(74,'receipt_header','','string',NULL,'2025-12-09 10:17:10'),(75,'receipt_footer','','string',NULL,'2025-12-09 10:17:10'),(76,'receipt_show_logo','0','string',NULL,'2025-12-09 10:17:10'),(77,'receipt_show_qr','0','string',NULL,'2025-12-09 10:17:10'),(78,'business_latitude','','string',NULL,'2025-12-09 10:17:10'),(79,'business_longitude','','string',NULL,'2025-12-09 10:17:10'),(80,'delivery_base_fee','','string',NULL,'2025-12-09 10:17:10'),(81,'delivery_per_km_rate','','string',NULL,'2025-12-09 10:17:10'),(82,'delivery_max_active_jobs','3','string',NULL,'2025-12-09 10:17:10'),(83,'delivery_sla_pending_limit','15','string',NULL,'2025-12-09 10:17:10'),(84,'delivery_sla_assigned_limit','10','string',NULL,'2025-12-09 10:17:10'),(85,'delivery_sla_delivery_limit','45','string',NULL,'2025-12-09 10:17:10'),(86,'delivery_sla_slack_minutes','5','string',NULL,'2025-12-09 10:17:10'),(87,'google_maps_api_key','','string',NULL,'2025-12-09 10:17:10'),(88,'google_distance_matrix_endpoint','https://maps.googleapis.com/maps/api/distancematrix/json','string',NULL,'2025-12-09 10:17:10'),(89,'google_distance_matrix_timeout','10','string',NULL,'2025-12-09 10:17:10'),(90,'delivery_cache_ttl_minutes','1440','string',NULL,'2025-12-09 10:17:10'),(91,'delivery_cache_soft_ttl_minutes','180','string',NULL,'2025-12-09 10:17:10'),(92,'delivery_distance_fallback_provider','haversine','string',NULL,'2025-12-09 10:17:10'),(93,'accounting_auto_lock_days','0','string',NULL,'2025-12-09 10:17:10'),(94,'accounting_alert_email','','string',NULL,'2025-12-09 10:17:10'),(95,'enable_whatsapp_notifications','0','string',NULL,'2025-12-09 10:17:10'),(96,'whatsapp_access_token','','string',NULL,'2025-12-09 10:17:10'),(97,'whatsapp_phone_number_id','','string',NULL,'2025-12-09 10:17:10'),(98,'whatsapp_business_account_id','','string',NULL,'2025-12-09 10:17:10'),(99,'whatsapp_verify_token','','string',NULL,'2025-12-09 10:17:10'),(100,'whatsapp_auto_replies','0','string',NULL,'2025-12-09 10:17:10'),(101,'whatsapp_enabled','0','string',NULL,'2025-12-09 10:17:10'),(102,'notification_reply_to_email','','string',NULL,'2025-12-09 10:17:10'),(103,'require_register_session','0','string',NULL,'2025-12-09 10:17:10'),(104,'blind_close_enabled','0','string',NULL,'2025-12-09 10:17:10'),(105,'max_variance_without_approval','0','string',NULL,'2025-12-09 10:17:10'),(106,'branding_logo','','string',NULL,'2025-12-09 10:17:10'),(107,'branding_logo_light','','string',NULL,'2025-12-09 10:17:10'),(108,'branding_tagline','','string',NULL,'2025-12-09 10:17:10'),(109,'branding_primary_color','#2563eb','string',NULL,'2025-12-09 10:17:10'),(110,'branding_secondary_color','#1e293b','string',NULL,'2025-12-09 10:17:10'),(160,'backup_frequency','daily','string',NULL,'2025-12-09 10:18:12'),(161,'backup_time_of_day','02:00','string',NULL,'2025-12-09 10:18:12'),(162,'backup_weekday','monday','string',NULL,'2025-12-09 10:18:12'),(163,'backup_retention_days','30','string',NULL,'2025-12-09 10:18:12'),(164,'backup_storage_path','C:\\xampp\\htdocs\\wapos/backups','string',NULL,'2025-12-09 10:18:12');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_content`
--

DROP TABLE IF EXISTS `site_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_key` varchar(100) NOT NULL,
  `content` text DEFAULT NULL,
  `content_type` enum('text','textarea','richtext','html','json','image') DEFAULT 'text',
  `page` varchar(50) DEFAULT 'home',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_key` (`content_key`),
  KEY `idx_page` (`page`),
  KEY `idx_key` (`content_key`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_content`
--

LOCK TABLES `site_content` WRITE;
/*!40000 ALTER TABLE `site_content` DISABLE KEYS */;
INSERT INTO `site_content` VALUES (1,'home_hero_title','Complete Business Management System','text','home',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(2,'home_hero_subtitle','Point of Sale, Restaurant Operations, Inventory, Deliveries, Housekeeping, Maintenance, and Accounting — all in one unified platform.','textarea','home',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(3,'home_cta_button','Sign In to Dashboard','text','home',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(4,'company_name','WAPOS','text','global',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(5,'company_tagline','by Waesta Enterprises','text','global',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(6,'company_full_name','Waesta Enterprises U Ltd','text','global',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(7,'company_email','info@waesta.com','text','global',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(8,'company_phone','+254 700 000 000','text','global',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(9,'company_address','Nairobi, Kenya','textarea','global',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(10,'company_website','https://waesta.com','text','global',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(11,'about_title','About WAPOS','text','about',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(12,'about_content','WAPOS is a comprehensive point of sale and business management system designed for retail, restaurant, and hospitality businesses.','richtext','about',1,'2025-12-04 11:25:11','2025-12-04 11:25:24'),(13,'contact_title','Contact Us','text','contact',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(14,'contact_intro','Get in touch with our team for support or inquiries.','textarea','contact',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(15,'footer_copyright','© 2025 Waesta Enterprises U Ltd. All rights reserved.','text','global',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(16,'seo_title','WAPOS - Unified Point of Sale System','text','seo',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(17,'seo_description','WAPOS is a comprehensive point of sale system for retail, restaurant, and hospitality businesses.','textarea','seo',1,'2025-12-04 11:25:11','2025-12-04 11:25:11'),(18,'seo_keywords','POS system, point of sale, retail POS, restaurant POS','textarea','seo',1,'2025-12-04 11:25:11','2025-12-04 11:25:11');
/*!40000 ALTER TABLE `site_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_templates`
--

DROP TABLE IF EXISTS `sms_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `message` varchar(160) NOT NULL,
  `template_type` enum('marketing','transactional','appreciation','reminder','alert') DEFAULT 'transactional',
  `variables` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`variables`)),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_templates`
--

LOCK TABLES `sms_templates` WRITE;
/*!40000 ALTER TABLE `sms_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_adjustments`
--

DROP TABLE IF EXISTS `stock_adjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_item_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `adjustment_type` enum('manual','wastage','transfer','audit') NOT NULL DEFAULT 'manual',
  `quantity` decimal(18,4) NOT NULL,
  `unit_cost` decimal(15,4) DEFAULT 0.0000,
  `reason` text DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  KEY `idx_stock_adjustments_item` (`inventory_item_id`),
  KEY `idx_stock_adjustments_product` (`product_id`),
  CONSTRAINT `stock_adjustments_ibfk_1` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustments_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_adjustments_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_adjustments_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_adjustments`
--

LOCK TABLES `stock_adjustments` WRITE;
/*!40000 ALTER TABLE `stock_adjustments` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_adjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_item_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `movement_type` enum('purchase','transfer','adjustment','sale','consumption','wastage') NOT NULL,
  `direction` enum('in','out') NOT NULL,
  `quantity` decimal(18,4) NOT NULL,
  `unit_cost` decimal(15,4) DEFAULT 0.0000,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` int(10) unsigned DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_stock_movements_item` (`inventory_item_id`),
  KEY `idx_stock_movements_reference` (`reference_type`,`reference_id`),
  CONSTRAINT `stock_movements_ibfk_1` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_movements_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_movements_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_transfers`
--

DROP TABLE IF EXISTS `stock_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_transfers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `source_location_id` int(10) unsigned NOT NULL,
  `destination_location_id` int(10) unsigned NOT NULL,
  `reference_number` varchar(100) NOT NULL,
  `status` enum('draft','in_transit','completed','cancelled') DEFAULT 'draft',
  `initiated_by` int(10) unsigned DEFAULT NULL,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `initiated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_transfer_ref` (`reference_number`),
  KEY `source_location_id` (`source_location_id`),
  KEY `destination_location_id` (`destination_location_id`),
  KEY `initiated_by` (`initiated_by`),
  KEY `approved_by` (`approved_by`),
  KEY `idx_transfer_status` (`status`),
  CONSTRAINT `stock_transfers_ibfk_1` FOREIGN KEY (`source_location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `stock_transfers_ibfk_2` FOREIGN KEY (`destination_location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `stock_transfers_ibfk_3` FOREIGN KEY (`initiated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `stock_transfers_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_transfers`
--

LOCK TABLES `stock_transfers` WRITE;
/*!40000 ALTER TABLE `stock_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `tax_number` varchar(50) DEFAULT NULL,
  `payment_terms` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_suppliers_deleted` (`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'ABC Wholesale','John Smith',NULL,'+1234567890','john@abcwholesale.com',NULL,NULL,NULL,NULL,1,'2025-12-01 06:53:14','2025-12-01 06:53:14',NULL),(2,'XYZ Distributors','Jane Doe',NULL,'+0987654321','jane@xyzdist.com',NULL,NULL,NULL,NULL,1,'2025-12-01 06:53:14','2025-12-01 06:53:14',NULL),(3,'Global Supply Co','Mike Johnson',NULL,'+1122334455','mike@globalsupply.com',NULL,NULL,NULL,NULL,1,'2025-12-01 06:53:14','2025-12-01 06:53:14',NULL);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync_queue`
--

DROP TABLE IF EXISTS `sync_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sync_queue` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(100) NOT NULL,
  `entity_id` bigint(20) unsigned NOT NULL,
  `action` enum('create','update','delete') NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `priority` tinyint(3) unsigned DEFAULT 5,
  `status` enum('pending','processing','completed','failed') DEFAULT 'pending',
  `retries` tinyint(3) unsigned DEFAULT 0,
  `last_error` text DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sync_queue_status` (`status`,`priority`,`scheduled_at`),
  KEY `idx_sync_queue_entity` (`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_queue`
--

LOCK TABLES `sync_queue` WRITE;
/*!40000 ALTER TABLE `sync_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_actions`
--

DROP TABLE IF EXISTS `system_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `action_key` varchar(50) NOT NULL,
  `is_sensitive` tinyint(1) DEFAULT 0,
  `requires_approval` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `action_key` (`action_key`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_actions`
--

LOCK TABLES `system_actions` WRITE;
/*!40000 ALTER TABLE `system_actions` DISABLE KEYS */;
INSERT INTO `system_actions` VALUES (1,'view','View/Read','View and read data','view',0,0,'2025-12-03 13:58:04'),(2,'create','Create/Add','Create new records','create',0,0,'2025-12-03 13:58:04'),(3,'update','Edit/Update','Modify existing records','update',0,0,'2025-12-03 13:58:04'),(4,'delete','Delete/Remove','Delete records','delete',1,1,'2025-12-03 13:58:04'),(5,'void','Void Transaction','Void sales and transactions','void',1,1,'2025-12-03 13:58:04'),(6,'refund','Process Refunds','Handle customer refunds','refund',1,1,'2025-12-03 13:58:04'),(7,'discount','Apply Discounts','Apply discounts to charges','discount',1,0,'2025-12-03 13:58:04'),(8,'override_price','Override Prices','Override product prices','override_price',1,1,'2025-12-03 13:58:04'),(9,'manage_cash','Manage Cash Drawer','Open/close cash drawer','manage_cash',1,0,'2025-12-03 13:58:04'),(10,'split_payment','Split Payments','Process split payments','split_payment',0,0,'2025-12-03 13:58:04'),(11,'layaway','Layaway/Hold','Create layaway transactions','layaway',0,0,'2025-12-03 13:58:04'),(12,'adjust_inventory','Adjust Inventory','Make inventory adjustments','adjust_inventory',1,1,'2025-12-03 13:58:04'),(13,'transfer_stock','Transfer Stock','Transfer inventory between locations','transfer_stock',1,0,'2025-12-03 13:58:04'),(14,'receive_stock','Receive Stock','Receive inventory shipments','receive_stock',0,0,'2025-12-03 13:58:04'),(15,'count_inventory','Count Inventory','Perform inventory counts','count_inventory',0,0,'2025-12-03 13:58:04'),(16,'modify_order','Modify Orders','Modify restaurant orders','modify_order',0,0,'2025-12-03 13:58:04'),(17,'kitchen_display','Kitchen Display','Access kitchen display system','kitchen_display',0,0,'2025-12-03 13:58:04'),(18,'table_management','Table Management','Manage restaurant tables','table_management',0,0,'2025-12-03 13:58:04'),(19,'loyalty_points','Loyalty Points','Manage customer loyalty points','loyalty_points',0,0,'2025-12-03 13:58:04'),(20,'customer_credit','Customer Credit','Manage customer credit accounts','customer_credit',1,1,'2025-12-03 13:58:04'),(21,'send_receipts','Send Receipts','Email/SMS receipts to guests','send_receipts',0,0,'2025-12-03 13:58:04'),(22,'view_reports','View Reports','Access performance and KPI reports','view_reports',0,0,'2025-12-03 13:58:04'),(23,'financial_reports','Financial Reports','Access financial statements','financial_reports',1,0,'2025-12-03 13:58:04'),(24,'export','Export Data','Export reports and datasets','export',0,0,'2025-12-03 13:58:04'),(25,'print','Print','Print receipts and reports','print',0,0,'2025-12-03 13:58:04'),(26,'manage_users','Manage Users','Create and manage user accounts','manage_users',1,1,'2025-12-03 13:58:04'),(27,'change_permissions','Change Permissions','Modify user permissions','change_permissions',1,1,'2025-12-03 13:58:04'),(28,'system_settings','System Settings','Modify system configuration','system_settings',1,1,'2025-12-03 13:58:04'),(29,'backup_restore','Backup/Restore','Perform system backup and restore','backup_restore',1,1,'2025-12-03 13:58:04'),(30,'audit_logs','Audit Logs','View audit and incident logs','audit_logs',1,0,'2025-12-03 13:58:04'),(31,'location_reports','Location Reports','View location-specific reports','location_reports',0,0,'2025-12-03 13:58:04'),(32,'cross_location','Cross Location','Access multiple locations','cross_location',1,0,'2025-12-03 13:58:04'),(33,'api_access','API Access','Access system APIs','api_access',1,1,'2025-12-03 13:58:04'),(34,'integrations','Integrations','Manage third-party integrations','integrations',1,1,'2025-12-03 13:58:04'),(35,'tax_management','Tax Management','Manage tax settings and calculations','tax_management',1,1,'2025-12-03 13:58:04');
/*!40000 ALTER TABLE `system_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_level` enum('debug','info','warning','error','critical') DEFAULT 'info',
  `category` varchar(50) NOT NULL DEFAULT 'general',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `request_uri` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_level` (`log_level`),
  KEY `idx_category` (`category`),
  KEY `idx_created` (`created_at`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_modules`
--

DROP TABLE IF EXISTS `system_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `module_key` varchar(50) NOT NULL,
  `parent_module_id` int(10) unsigned DEFAULT NULL,
  `icon` varchar(50) DEFAULT 'bi-circle',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `module_key` (`module_key`),
  KEY `parent_module_id` (`parent_module_id`),
  CONSTRAINT `system_modules_ibfk_1` FOREIGN KEY (`parent_module_id`) REFERENCES `system_modules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_modules`
--

LOCK TABLES `system_modules` WRITE;
/*!40000 ALTER TABLE `system_modules` DISABLE KEYS */;
INSERT INTO `system_modules` VALUES (1,'dashboard','Dashboard','Main dashboard and overview','dashboard',NULL,'bi-speedometer2',1,1,'2025-12-03 13:58:04'),(2,'pos','Point of Sale','Retail POS operations','pos',NULL,'bi-cart-plus',2,1,'2025-12-03 13:58:04'),(3,'restaurant','Restaurant','Restaurant operations and orders','restaurant',NULL,'bi-shop',3,1,'2025-12-03 13:58:04'),(4,'rooms','Room Management','Hotel room booking and management','rooms',NULL,'bi-building',4,1,'2025-12-03 13:58:04'),(5,'delivery','Delivery','Delivery management and tracking','delivery',NULL,'bi-truck',5,1,'2025-12-03 13:58:04'),(6,'products','Products','Product and inventory management','products',NULL,'bi-box-seam',6,1,'2025-12-03 13:58:04'),(7,'sales','Sales','Sales history and management','sales',NULL,'bi-receipt',7,1,'2025-12-03 13:58:04'),(8,'customers','Customers','Customer management','customers',NULL,'bi-people',8,1,'2025-12-03 13:58:04'),(9,'reports','Reports','Business reports and analytics','reports',NULL,'bi-graph-up',9,1,'2025-12-03 13:58:04'),(10,'accounting','Accounting','Financial accounting and expenses','accounting',NULL,'bi-calculator',10,1,'2025-12-03 13:58:04'),(11,'users','User Management','User and permission management','users',NULL,'bi-person-badge',11,1,'2025-12-03 13:58:04'),(12,'settings','Settings','System settings and configuration','settings',NULL,'bi-gear',12,1,'2025-12-03 13:58:04'),(13,'locations','Locations','Multi-location management','locations',NULL,'bi-geo-alt',13,1,'2025-12-03 13:58:04'),(14,'manage_tables','Manage Tables','Restaurant table management','manage_tables',NULL,'bi-table',14,1,'2025-12-03 13:58:04'),(15,'manage_rooms','Manage Rooms','Room type and room management','manage_rooms',NULL,'bi-door-open',15,1,'2025-12-03 13:58:04'),(31,'FrontDesk','Front Desk','Guest check-in, check-out, and lobby operations.','frontdesk',NULL,'bi-bell',16,1,'2025-12-03 13:59:52'),(32,'Housekeeping','Housekeeping','Room readiness, cleaning schedules, and inspections.','housekeeping',NULL,'bi-brush',17,1,'2025-12-03 13:59:52'),(33,'Maintenance','Maintenance','Facility upkeep, work orders, and technician dispatch.','maintenance',NULL,'bi-tools',18,1,'2025-12-03 13:59:52'),(34,'Concierge','Concierge','Guest experiences, itineraries, and VIP services.','concierge',NULL,'bi-star',19,1,'2025-12-03 13:59:52'),(35,'Spa','Spa & Wellness','Spa treatments, therapist schedules, and billing.','spa',NULL,'bi-heart',20,1,'2025-12-03 13:59:52'),(36,'Events','Events & Banquets','Event planning, banquets, and conference services.','events',NULL,'bi-calendar-event',21,1,'2025-12-03 13:59:52'),(37,'RoomService','Room Service','In-room dining orders and dispatch.','room_service',NULL,'bi-cup-hot',22,1,'2025-12-03 13:59:52'),(38,'Security','Security','Security patrols, incident logs, and escalations.','security',NULL,'bi-shield-lock',23,1,'2025-12-03 13:59:52'),(39,'HR','HR & Compliance','Human resources, onboarding, and compliance tasks.','hr',NULL,'bi-people',24,1,'2025-12-03 13:59:52'),(40,'Revenue','Revenue Management','Pricing, forecasting, and yield management.','revenue',NULL,'bi-graph-up-arrow',25,1,'2025-12-03 13:59:52'),(41,'SalesOffice','Corporate Sales','Corporate contracts and travel agent negotiations.','sales_office',NULL,'bi-briefcase',26,1,'2025-12-03 13:59:52');
/*!40000 ALTER TABLE `system_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_reservations`
--

DROP TABLE IF EXISTS `table_reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `table_reservations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned DEFAULT NULL,
  `guest_name` varchar(150) NOT NULL,
  `guest_phone` varchar(30) NOT NULL,
  `party_size` int(11) NOT NULL,
  `reservation_date` date NOT NULL,
  `reservation_time` time NOT NULL,
  `duration_minutes` int(11) NOT NULL DEFAULT 120,
  `status` varchar(30) NOT NULL DEFAULT 'confirmed',
  `special_requests` text DEFAULT NULL,
  `internal_notes` text DEFAULT NULL,
  `deposit_required` tinyint(1) NOT NULL DEFAULT 0,
  `deposit_amount` decimal(10,2) DEFAULT NULL,
  `deposit_due_at` datetime DEFAULT NULL,
  `deposit_status` varchar(30) NOT NULL DEFAULT 'not_required',
  `deposit_total_paid` decimal(10,2) NOT NULL DEFAULT 0.00,
  `deposit_payment_method` varchar(50) DEFAULT NULL,
  `deposit_reference` varchar(100) DEFAULT NULL,
  `deposit_paid_at` datetime DEFAULT NULL,
  `cancellation_policy` text DEFAULT NULL,
  `deposit_notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `seated_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reservations_customer` (`customer_id`),
  KEY `fk_reservations_creator` (`created_by`),
  KEY `idx_reservation_date` (`reservation_date`),
  KEY `idx_reservation_table` (`table_id`),
  KEY `idx_reservation_status` (`status`),
  CONSTRAINT `fk_reservations_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_reservations_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_reservations_table` FOREIGN KEY (`table_id`) REFERENCES `restaurant_tables` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_reservations`
--

LOCK TABLES `table_reservations` WRITE;
/*!40000 ALTER TABLE `table_reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `table_reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_memberships`
--

DROP TABLE IF EXISTS `user_group_memberships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group_memberships` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  `assigned_by` int(10) unsigned DEFAULT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_group` (`user_id`,`group_id`),
  KEY `group_id` (`group_id`),
  KEY `assigned_by` (`assigned_by`),
  KEY `idx_user_group_memberships_user_id` (`user_id`),
  CONSTRAINT `user_group_memberships_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_group_memberships_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `permission_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_group_memberships_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_memberships`
--

LOCK TABLES `user_group_memberships` WRITE;
/*!40000 ALTER TABLE `user_group_memberships` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_group_memberships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `module_id` int(10) unsigned NOT NULL,
  `action_id` int(10) unsigned NOT NULL,
  `is_granted` tinyint(1) DEFAULT 1,
  `permission_type` enum('allow','deny') DEFAULT 'allow',
  `conditions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`conditions`)),
  `granted_by` int(10) unsigned DEFAULT NULL,
  `granted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `reason` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_permission` (`user_id`,`module_id`,`action_id`),
  KEY `module_id` (`module_id`),
  KEY `action_id` (`action_id`),
  KEY `granted_by` (`granted_by`),
  KEY `idx_user_permissions_user_id` (`user_id`),
  CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_2` FOREIGN KEY (`module_id`) REFERENCES `system_modules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_3` FOREIGN KEY (`action_id`) REFERENCES `system_actions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_4` FOREIGN KEY (`granted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
INSERT INTO `user_permissions` VALUES (1,19,2,2,1,'allow',NULL,1,'2025-12-03 14:27:38',NULL,'');
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_registers`
--

DROP TABLE IF EXISTS `user_registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_registers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `register_id` int(10) unsigned NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_register` (`user_id`,`register_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_registers`
--

LOCK TABLES `user_registers` WRITE;
/*!40000 ALTER TABLE `user_registers` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_registers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expires_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_active` tinyint(1) DEFAULT 1,
  `location_id` int(10) unsigned DEFAULT NULL,
  `device_fingerprint` varchar(255) DEFAULT NULL,
  `two_factor_verified` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `idx_user_sessions_user_id` (`user_id`),
  KEY `idx_user_sessions_expires_at` (`expires_at`),
  CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_sessions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sessions`
--

LOCK TABLES `user_sessions` WRITE;
/*!40000 ALTER TABLE `user_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_two_factor`
--

DROP TABLE IF EXISTS `user_two_factor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_two_factor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `secret_key` varchar(255) NOT NULL,
  `backup_codes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`backup_codes`)),
  `is_enabled` tinyint(1) DEFAULT 0,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `user_two_factor_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_two_factor`
--

LOCK TABLES `user_two_factor` WRITE;
/*!40000 ALTER TABLE `user_two_factor` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_two_factor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` enum('super_admin','admin','manager','accountant','cashier','waiter','inventory_manager','rider','frontdesk','housekeeping_manager','housekeeping_staff','maintenance_manager','maintenance_staff','technician','engineer','developer','front_office_manager','guest_relations_manager','concierge','spa_manager','spa_staff','events_manager','banquet_supervisor','room_service_manager','room_service_staff','security_manager','security_staff','hr_manager','hr_staff','revenue_manager','sales_manager','sales_executive') DEFAULT 'cashier',
  `location_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_username` (`username`),
  KEY `idx_role` (`role`),
  KEY `idx_users_location` (`location_id`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_active` (`is_active`),
  KEY `idx_users_deleted` (`deleted_at`),
  CONSTRAINT `fk_users_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$10$bnt2VkeLp4KOf1pRzkJLRuRtqRO5QK3CSeQtUgQGU3x8hI7xsXmEu','Administrator','admin@wapos.local',NULL,'admin',NULL,1,'2025-12-04 12:22:37','2025-11-26 12:40:22','2025-12-04 09:22:37',NULL),(9,'superadmin','$argon2id$v=19$m=65536,t=4,p=1$d0FmR1M2QVMubnBTQmNwYw$xJWCuDx4S5R8k+xXMxNQpa4Emh+aJ4/4lzCM8QkhrnE','Super Administrator','admin@waesta.com','+254701111111','super_admin',NULL,1,'2025-12-09 16:29:50','2025-11-27 13:48:24','2025-12-09 13:29:51',NULL),(10,'Receptionist','$argon2id$v=19$m=65536,t=4,p=1$RERORmpKYU42TkVZc25YaQ$UOpiBm0/nXRknDp+fj/iBclg1PwVOdQWBYQa67GxcMQ','Front Desk Receptionist','receptionist@example.com',NULL,'frontdesk',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:09',NULL),(11,'Cashier','$argon2id$v=19$m=65536,t=4,p=1$b0o5T2ZrZ2U1UUdrZHFJNA$mvMX9EbAk//l2JDoQKEebYSfO3mI4vQaQNgK1WKiyMQ','Point of Sale Cashier','cashier@example.com',NULL,'cashier',NULL,1,'2025-12-03 13:03:02','2025-12-03 09:56:09','2025-12-03 10:03:02',NULL),(12,'Technician','$argon2id$v=19$m=65536,t=4,p=1$T1Z4SllGdmNleTJnbnQ2eQ$QhMYcHlLpQHNoIiH66SFNTcjG9iSqji2HN6ehLVmcys','On-site Technician','technician@example.com',NULL,'technician',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:10',NULL),(13,'RoomAttendant','$argon2id$v=19$m=65536,t=4,p=1$eU5mLnNqOVV2MTNBN1l1OA$V0OJeCT1/eh5elBN12mrLnX0BEgNURztthkgH1zQH88','Room Attendant','roomattendant@example.com',NULL,'housekeeping_staff',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:10',NULL),(14,'Electrician','$argon2id$v=19$m=65536,t=4,p=1$enJnVWp2ZTluaFJPTFRMMw$q/gkTVE5oqpba9Xci8W08Df0zKqOogghz6SEwVAuVTs','Maintenance Electrician','electrician@example.com',NULL,'maintenance_staff',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:10',NULL),(15,'Waiter','$argon2id$v=19$m=65536,t=4,p=1$ZDNkZGVmSFlPeG9jQ1QwNw$taVw95ywLd0Yoj5h7xqywE6j6/l2nQ9P7rAZ1DTC17A','Service Waiter/Waitress','waiter@example.com',NULL,'waiter',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:10',NULL),(16,'Concierge','$argon2id$v=19$m=65536,t=4,p=1$MkVhWHhOUFhrYXZwRDR3WA$TA90l31ajKEuUB/bwA2UN16EKYhfAWs/HyJPI2bmgTI','Guest Concierge','concierge@example.com',NULL,'frontdesk',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:11',NULL),(17,'LaundryAttendant','$argon2id$v=19$m=65536,t=4,p=1$Sy5JM3B1SnZnNmltRE90Rg$mSWGb7B3eZ0bf+aS0nUhJHv0OGzOnorJwXkJoB70pvM','Laundry Attendant','laundryattendant@example.com',NULL,'housekeeping_staff',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:11',NULL),(18,'Chef','$argon2id$v=19$m=65536,t=4,p=1$bmt2d0kwdm1sMm5xQldTRg$Qf/mYVpLp2bupfY7MlW+Jv8oo0jnVUwoWwbN/KnBc0s','Chef / Cook','chef@example.com',NULL,'manager',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:11',NULL),(19,'Barista','$argon2id$v=19$m=65536,t=4,p=1$UjEzWmVMUUR3Mzloekcwcg$+c3bvCLDppuJYrEYw+/8HJNcvMqHq58rmxEqF2gWryY','Barista / Barman','barista@example.com',NULL,'waiter',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:12',NULL),(20,'StockController','$argon2id$v=19$m=65536,t=4,p=1$ZFVLVTBlT2hBMms5NXhOUg$AziWigb92qAMvUttZldKUiF0ROmA0Nb6LsbO/LL3VMM','Stock Controller','stockcontroller@example.com',NULL,'inventory_manager',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:12',NULL),(21,'Accountant','$argon2id$v=19$m=65536,t=4,p=1$eW1oaGpHTlpwSU1VbDJqZw$fFZdRV21MBnuvjvOeZ8FtmzejW5zCWXMgcZbRWn0j7c','Finance Accountant','accountant@example.com',NULL,'accountant',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:12',NULL),(22,'Manager','$argon2id$v=19$m=65536,t=4,p=1$ZkJpZEdFMVZOTnlFSFd2aA$0Vwr76BUUoA54A3XrEgcctK0uTvz6b9PoQzVVkj3Bpk','Operations Manager','manager@example.com',NULL,'manager',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:12',NULL),(23,'Supervisor','$argon2id$v=19$m=65536,t=4,p=1$WFBXcGdSSm9vQzR4VzNibA$2rzDEql/cOw/Ol0Co9Sz0bOp0GEkKswVCRDtn6rW5aw','Floor Supervisor','supervisor@example.com',NULL,'manager',NULL,1,NULL,'2025-12-03 09:56:09','2025-12-03 09:56:13',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `void_reason_codes`
--

DROP TABLE IF EXISTS `void_reason_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `void_reason_codes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `display_name` varchar(120) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `category` enum('customer_request','kitchen_error','cashier_error','inventory_issue','other') DEFAULT 'other',
  `display_order` int(10) unsigned NOT NULL DEFAULT 0,
  `requires_manager_approval` tinyint(1) DEFAULT 0,
  `affects_inventory` tinyint(1) DEFAULT 1,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `void_reason_codes`
--

LOCK TABLES `void_reason_codes` WRITE;
/*!40000 ALTER TABLE `void_reason_codes` DISABLE KEYS */;
INSERT INTO `void_reason_codes` VALUES (1,'KITCHEN_ERROR','Kitchen Error','Food preparation issue','kitchen_error',10,0,1,1,'2025-11-27 14:23:22','2025-11-27 14:23:22'),(2,'CUSTOMER_CANCEL','Customer Cancellation','Customer requested cancellation','customer_request',20,0,1,1,'2025-11-27 14:23:22','2025-11-27 14:23:22'),(3,'PAYMENT_ISSUE','Payment Issue','Payment failed or disputed','cashier_error',30,1,1,1,'2025-11-27 14:23:22','2025-11-27 14:23:22'),(4,'ITEM_UNAVAILABLE','Item Unavailable','Ordered items not available','inventory_issue',40,0,1,1,'2025-11-27 14:23:22','2025-11-27 14:23:22'),(5,'WRONG_ORDER','Wrong Order','Incorrect order entry','cashier_error',50,0,1,1,'2025-11-27 14:23:22','2025-11-27 14:23:22'),(6,'SYSTEM_ERROR','System Error','Technical malfunction','other',60,1,0,1,'2025-11-27 14:23:22','2025-11-27 14:23:22'),(7,'DUPLICATE_ORDER','Duplicate Order','Order entered multiple times','cashier_error',70,0,1,1,'2025-11-27 14:23:22','2025-11-27 14:23:22'),(8,'CUSTOMER_COMPLAINT','Customer Complaint','Complaint-driven void','customer_request',80,1,1,1,'2025-11-27 14:23:22','2025-11-27 14:23:22'),(9,'DELIVERY_FAILED','Delivery Failed','Unable to deliver order','other',90,0,1,1,'2025-11-27 14:23:22','2025-11-27 14:23:22'),(10,'MANAGER_OVERRIDE','Manager Override','Discretionary void','other',100,1,1,1,'2025-11-27 14:23:22','2025-11-27 14:23:22');
/*!40000 ALTER TABLE `void_reason_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `void_settings`
--

DROP TABLE IF EXISTS `void_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `void_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','number','boolean','json') DEFAULT 'string',
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `void_settings`
--

LOCK TABLES `void_settings` WRITE;
/*!40000 ALTER TABLE `void_settings` DISABLE KEYS */;
INSERT INTO `void_settings` VALUES (1,'void_time_limit_minutes','60','number','Time limit (minutes) to void without manager approval','2025-11-27 14:23:23','2025-11-27 14:23:23'),(2,'require_manager_approval_amount','1000.00','number','Threshold requiring manager approval','2025-11-27 14:23:23','2025-11-27 14:23:23'),(3,'auto_adjust_inventory','1','boolean','Auto inventory adjustment on void','2025-11-27 14:23:23','2025-11-27 14:23:23'),(4,'print_void_receipt','1','boolean','Print receipt after void','2025-11-27 14:23:23','2025-11-27 14:23:23'),(5,'allow_partial_void','0','boolean','Allow partial order voids','2025-11-27 14:23:23','2025-11-27 14:23:23'),(6,'void_notification_email','','string','Email for void alerts','2025-11-27 14:23:23','2025-11-27 14:23:23'),(7,'void_daily_limit','10','number','Max voids per user per day','2025-11-27 14:23:23','2025-11-27 14:23:23'),(8,'void_audit_retention_days','365','number','Retention period for void logs','2025-11-27 14:23:23','2025-11-27 14:23:23');
/*!40000 ALTER TABLE `void_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `void_transactions`
--

DROP TABLE IF EXISTS `void_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `void_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `order_type` enum('dine_in','takeaway','delivery','room_service','other') DEFAULT 'other',
  `order_number` varchar(50) NOT NULL,
  `original_total` decimal(15,2) NOT NULL,
  `void_reason_code` varchar(50) NOT NULL,
  `void_reason_text` text DEFAULT NULL,
  `voided_by_user_id` int(10) unsigned NOT NULL,
  `manager_user_id` int(10) unsigned DEFAULT NULL,
  `manager_approval_user_id` int(10) unsigned DEFAULT NULL,
  `void_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `financial_impact` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`financial_impact`)),
  `inventory_adjustments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`inventory_adjustments`)),
  `receipt_printed` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `manager_approval_user_id` (`manager_approval_user_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_void_timestamp` (`void_timestamp`),
  KEY `idx_voided_by` (`voided_by_user_id`),
  KEY `fk_void_transactions_manager` (`manager_user_id`),
  CONSTRAINT `fk_void_transactions_manager` FOREIGN KEY (`manager_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `void_transactions_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `void_transactions_ibfk_2` FOREIGN KEY (`voided_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `void_transactions_ibfk_3` FOREIGN KEY (`manager_approval_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `void_transactions`
--

LOCK TABLES `void_transactions` WRITE;
/*!40000 ALTER TABLE `void_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `void_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weather_data`
--

DROP TABLE IF EXISTS `weather_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weather_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `source` varchar(100) NOT NULL,
  `location` varchar(150) NOT NULL,
  `temperature_c` decimal(5,2) DEFAULT NULL,
  `humidity_percent` decimal(5,2) DEFAULT NULL,
  `conditions` varchar(100) DEFAULT NULL,
  `wind_speed_kmh` decimal(6,2) DEFAULT NULL,
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_weather_location_time` (`location`,`recorded_at`),
  KEY `idx_weather_source` (`source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weather_data`
--

LOCK TABLES `weather_data` WRITE;
/*!40000 ALTER TABLE `weather_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `weather_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `whatsapp_carts`
--

DROP TABLE IF EXISTS `whatsapp_carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whatsapp_carts` (
  `phone` varchar(20) NOT NULL,
  `cart_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`cart_data`)),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whatsapp_carts`
--

LOCK TABLES `whatsapp_carts` WRITE;
/*!40000 ALTER TABLE `whatsapp_carts` DISABLE KEYS */;
/*!40000 ALTER TABLE `whatsapp_carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `whatsapp_conversation_states`
--

DROP TABLE IF EXISTS `whatsapp_conversation_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whatsapp_conversation_states` (
  `phone` varchar(20) NOT NULL,
  `state_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`state_data`)),
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whatsapp_conversation_states`
--

LOCK TABLES `whatsapp_conversation_states` WRITE;
/*!40000 ALTER TABLE `whatsapp_conversation_states` DISABLE KEYS */;
/*!40000 ALTER TABLE `whatsapp_conversation_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `whatsapp_messages`
--

DROP TABLE IF EXISTS `whatsapp_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whatsapp_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` varchar(255) DEFAULT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `message_type` enum('inbound','outbound') NOT NULL,
  `content_type` varchar(50) DEFAULT 'text',
  `message_text` text DEFAULT NULL,
  `media_url` varchar(500) DEFAULT NULL,
  `template_name` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'received',
  `is_read` tinyint(1) DEFAULT 0,
  `replied_by` int(10) unsigned DEFAULT NULL,
  `replied_at` datetime DEFAULT NULL,
  `booking_id` int(10) unsigned DEFAULT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `api_response` text DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `message_id` (`message_id`),
  KEY `idx_phone` (`customer_phone`),
  KEY `idx_status` (`status`),
  KEY `idx_read` (`is_read`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whatsapp_messages`
--

LOCK TABLES `whatsapp_messages` WRITE;
/*!40000 ALTER TABLE `whatsapp_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `whatsapp_messages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-11  7:14:16
